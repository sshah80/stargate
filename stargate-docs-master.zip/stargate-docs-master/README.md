# 📒 MkDocs as Code
[![Flowdock](https://img.shields.io/badge/chat-on%20Flowdock-brightgreen.svg)](https://www.flowdock.com/app/uhg/mkdocs)  

MkDocs as Code for easy documentation pages

# 🎒 Setup
_It's easy as one, two, three_
1. Use [`compass`][compass] to create a new `mkdocs-as-code` repo for yourself, give the `mkdocs` GitHub user `Write` access to this repo, and enable the [webhook][webhook] so new pushes are automatically redeployed (_these steps will help automate redeployment_)
2. Modify the top environment parameters in your [`Jenkinsfile`](/Jenkinsfile) (_`ORG` and `REPO` are the only two that are necessary_)
3. Create a Jenkins **[Multibranch Pipeline][jenkins-config]** job in [this folder][jenkins] 

## GitHub Page
Once your job runs successfully, you should be able to see a `gh-pages` branch on your repo:

![](.github/img/gh-pages.png)

Then you can see in your repo settings that the page has been deployed:

![](.github/img/github-settings.png)

Finally, go to the URL to see how to get started configuring your webpage! 🎉

## 💡 Tips & Tricks
Use a [GitHub proxy][proxy] to get a custom/vanity URL!

### List of Known `MkDocs as Code` Pages
- [NextGenOps][nextgenops]
- [Jetson][jetson]
- [Compass][compass-docs]
- [Optum Identity Platform][oid]
- [Payment Integrity][opi]
- [OPI GHE Best Practices][opi-ghe]
- [Optum IQ Studio Workbench][iqsworkbench]

_Feel free to open a PR to add your page, or [click here][users] for a complete list_

[compass]: https://github.optum.com/paymentintegrity/compass
[mixin]: https://github.optum.com/jenkins/docker_build_agents/tree/master/mixins/jenkins_mixin_mkdocs
[proxy]: https://github.optum.com/Useful/github-proxy
[nextgenops]: https://nextgenoperations.optum.com
[jetson]: https://jetson.optum.com
[compass-docs]: https://compass.optum.com
[oid]: https://oid.optum.com
[users]: https://github.optum.com/search?q=filename%3AMKDOCS_USAGE.md&type=Code
[jenkins]: https://jenkins.optum.com/central/job/mkdocs-as-code
[opi]: https://paymentintegrity.optum.com
[opi-ghe]: https://github.optum.com/pages/paymentintegrity/ghe-best-practices
[webhook]: .github/img/gh-webhook.png
[jenkins-config]: .github/img/jenkins.png
[iqsworkbench]: https://iqsworkbench.optum.com/
