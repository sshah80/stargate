
Stargate is an Opensource API Gateway application based on [Kong API Gateway](https://konghq.com/solutions/gateway/), which itself is based on [OpenResty](https://openresty.org/en/) and [Nginx](https://nginx.org/en/). The application is organized as several **Environments**, each of which is comprised of two **Clusters**; a DMZ **Cluster** and a CORE **Cluster**, to facilitate the various routing flows.

## Stargate Cluster
A Stargate cluster is one "instance" of the Gateway, with components deployed to both CTC and ELR. Each **Environment** has two **Clusters**; a DMZ **Cluster** and a CORE **Cluster**. These differ only in the F5 VIPs which are exposed for them. The DMZ Cluster will have two VIPs, an internal vip containing `-dmz` in the hostname, and an external vip without the `-dmz`. The CORE cluster will only have a single internal vip, containing `-core` in the hostname.

#### Connection Management
The following diagram shows the connection management over the several hops of Stargate ingress.
<div class="img-magnifier-container">
<a target="_blank" href="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20Connection%20Management.png">
  <img id="conn-manage" src="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20Connection%20Management.png" width="800" height="210"></a>
  <script>
  magnify("conn-manage", 2.15);
  </script>
</div>
 

### CORE Cluster Infrastructure Diagram
Showing components owned by Stargate, or vital to core functions. Ommitted any integrations with external tooling (splunk, opentracing, DTSaaS, sitescope, etc).
<div class="img-magnifier-container">
<a target="_blank" href="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20CORE%20Cluster.png">
  <img id="core-cluster" src="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20CORE%20Cluster.png" width="800" height="400">
  </a>
  <script>
  magnify("core-cluster", 2.15);
  </script>
</div>

### DMZ Cluster Infrastructure Diagram
Showing components owned by Stargate, or vital to core functions. Ommitted any integrations with external tooling (splunk, opentracing, DTSaaS, sitescope, etc).
<div class="img-magnifier-container">
<a target="_blank" href="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20DMZ%20Cluster.png">
  <img id="dmz-cluster" src="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20DMZ%20Cluster.png" width="800" height="430"></a>
  <script>
  magnify("dmz-cluster", 2.15);
  </script>
</div>
<br/><br/>
 
[Full Instrastructure Diagram for Both Clusters](https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20Full%20Cluster2.png)

## Stargate Environment & Routing Flows
This image shows a full Stargate Environment, and all supported routing flows.

<a target="_blank" href="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20Environment3.png">
<div class="img-magnifier-container">
  <img id="full-env" src="https://github.optum.com/raw/APIGateway/stargate-docs/master/docs/assets/Stargate%20Environment3.png" width="800" height="1400"></a>
  <script>
  magnify("full-env", 2.15);
  </script>
</div>
