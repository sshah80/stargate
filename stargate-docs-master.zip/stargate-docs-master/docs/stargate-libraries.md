
This section describes libraries developed by Stargate for both API Providers and API Consumers to use in Gateway integrations.

## API Provider Libraries



### Spring Boot JWT Filter
This Spring Boot `@Autoconfigured` library provides a filter to validate [Stargate's Provider Side JWT](stargate-security.md#provider-side-stargate-jwt), and handle unauthorized requests.

| Specification    | Value |
|-------------------|-------|
| Language     | Java     |
| Current Version  | 1.x.x     |
| Docs & Installation    | [Github](https://github.optum.com/APIGateway/stargate-springboot-jwt-filter)   |
| Artifactory Repo | [Release](https://repo1.uhc.com/artifactory/webapp/#/artifacts/browse/tree/General/UHG-Releases/com/optum/stargate/springboot-jwt-filter) |
| Published | 5/2/19 |



## API Consumer Libraries

| Specification    | Value |
|-------------------|-------|
| Language     | Java     |
| Current Version  | 3.x.x     |
| Docs & Installation    | [Github](https://github.optum.com/APIGateway/stargate-client-auth)   |
| Artifactory Repo | [Release](https://repo1.uhc.com/artifactory/webapp/#/artifacts/browse/tree/General/UHG-Releases/com/optum/stargate/stargate-client-auth) |
| Published | 4/28/20 |
