
There are two types of resources you can create in self-service, stargate-namespace and stargate-proxy resources.

## stargate-namespace

### Create Stargate Namespace

See what each field means [here](stargate-self-service-fields.md#stargate-namespace)

```json
{
  "kind": "stargate-namespace",
  "action": "create",
  "spec": {
    "namespace": "teamname",
    "sloEmail": "bossman@optum.com",
    "teamEmailDL": "TeamDistroList@optum.com",
    "askId": "UHGWM-45675555",
    "adGroup": "myexample_adgroup"
  },
  "metadata": {
    "tags": [
      "somestring1",
      "somestring2"
    ],
    "override": {
      "autoMerge": true
    }
  }
}
```

### Update Stargate Namespace
(note the id now present in spec, you will find that visible in your resource after original creation in this repo). Note immutable fields are id and namespace due to restraints in current design:

```json
{
  "kind": "stargate-namespace",
  "action": "update",
  "spec": {
    "id": "uuidWillBeHere",
    "namespace": "teamname",
    "sloEmail": "bossman@optum.com",
    "teamEmailDL": "TeamDistroList@optum.com",
    "askId": "UHGWM-45676666",
    "adGroup": "myexample_new_adgroup"
  },
  "metadata": {
    "tags": [
      "somestring1",
      "somestring2"
    ],
    "override": {
      "autoMerge": true
    }
  }
}
}
```

### Delete Stargate Namespace
(note the id now present in spec, you will find that visible in your resource after original creation in this repo). Note immutable fields are id and namespace due to restraints in current design. Note on namespace deletes you must submit an "i approve" confirmation github PR comment post PR submission before it will process, as well as a "validate" comment seperately to kick off validation once more:

**Deleting your namespace is dangerous!**

It will remove:

  1. All proxies and dashboards created within your namespace
  2. All consumer access associated with your namespace
  3. All credentials associated with your namespace

```json
{
  "kind": "stargate-namespace",
  "action": "delete",
  "spec": {
    "id": "uuidWillBeHere",
    "namespace": "teamname",
    "sloEmail": "bossman@optum.com",
    "teamEmailDL": "TeamDistroList@optum.com",
    "askId": "UHGWM-45676666",
    "adGroup": "myexample_new_adgroup"
  },
  "metadata": {
    "tags": [
      "somestring1",
      "somestring2"
    ],
    "override": {
      "autoMerge": true
    }
  }
}
}
```


## stargate-proxy

### Create Stargate Proxy

See what each field means [here](stargate-self-service-fields.md#stargate-proxy)

```json
{
  "kind": "stargate-proxy",
  "action": "create",
  "spec": {
    "name": "my.api.stage",
    "url": "https://hostname-of-my-api-server:443/root/path",
    "proxyUrl": "",
    "auth": {"type": "oauth2", "grant": "client_credentials"},
    "connectTimeout": 2000,
    "readTimeout": 9000,
    "writeTimeout": 9000,
    "authorizedConsumers": [
      "upm",
      "opi",
      "myuhc"
    ],
    "options": {
      "specExpose": "http://optum.com/my/service/path/v1/spec.json",
      "cors": [".*[.]optum[.]com", "http://localhost", "https://myuhc.com"],
      "rateLimit": 33,
      "requestSizeLimiter": 2,
      "responseSizeLimiter": 5,
      "rateLimitByConsumer": [
        {
          "consumer": "upm",
          "rate": 15
        },
        {
          "consumer": "myuhc",
          "rate": 2
        }
      ]
    }
  },
  "metadata": {
    "namespace": "teamname",
    "certificationFileName": "",
    "proxyUrl": {
       "type": "api",
       "host": "gateway-stage-core.optum.com",
       "domain": "external",
       "sub-domain":"",
       "env":"alpha",
       "namespace":"",
       "resource":"myapiresource",
       "version":"v1"
    },
    "tags" : ["somestring1", "somestring2"],
    "override": {
      "autoMerge": true
    }
  }
}
```

### Update Stargate Proxy

(note the routeId/serviceId now present in spec, you will find that visible in your resource after original creation in this repo). Note immutable fields are routeId/serviceId and namespace due to restraints in current design:

```json
{
  "kind": "stargate-proxy",
  "action": "update",
  "spec": {
    "name": "my.api.stage2",
    "routeId": "uuidWillBeHere",
    "serviceId": "uuidWillBeHere",
    "url": "https://hostname-of-my-api-server:443/root/path",
    "proxyUrl": "https://gateway-stage-core.optum.com/api/alpha/ext/myapiresource2/v2",
    "auth": {"type": "oauth2", "grant": "client_credentials"},
    "connectTimeout": 2000,
    "readTimeout": 9000,
    "writeTimeout": 9000,
    "authorizedConsumers": [
      "upm",
      "opi",
      "myuhc"
    ],
    "options": {
      "specExpose": "http://optum.com/my/service/path/v1/spec.json",
      "cors": [".*[.]optum[.]com"],
      "rateLimit": 60,
      "requestSizeLimiter": 2,
      "responseSizeLimiter": 5,
      "rateLimitByConsumer": [
        {
          "consumer": "upm",
          "rate": 35
        },
        {
          "consumer": "myuhc",
          "rate": 4
        }
      ]
    }
  },
  "metadata": {
    "namespace": "teamname",
    "certificationFileName": "",
    "proxyUrl": {
       "type": "api",
       "host": "gateway-stage-core.optum.com",
       "domain": "external",
       "sub-domain":"",
       "env":"alpha",
       "namespace":"",
       "resource":"myapiresource2",
       "version":"v2"
    },
    "tags" : ["somestring1", "somestring2"],
    "override": {
      "autoMerge": true
    }
  }
}
```

### Delete Stargate Proxy

```json
{
  "kind": "stargate-proxy",
  "action": "delete",
  "spec": {
    "name": "my.api.stage2",
    "routeId": "uuidWillBeHere",
    "serviceId": "uuidWillBeHere",
    "url": "https://hostname-of-my-api-server:443/root/path",
    "proxyUrl": "https://gateway-stage-core.optum.com/api/alpha/ext/myapiresource2/v2",
    "auth": {"type": "oauth2", "grant": "client_credentials"},
    "connectTimeout": 2000,
    "readTimeout": 9000,
    "writeTimeout": 9000,
    "authorizedConsumers": [
      "upm",
      "opi",
      "myuhc"
    ],
    "options": {
      "specExpose": "http://optum.com/my/service/path/v1/spec.json",
       "cors": [".*[.]optum[.]com"],
      "rateLimit": 60,
      "rateLimitByConsumer": [
        {
          "consumer": "upm",
          "rate": 35
        },
        {
          "consumer": "myuhc",
          "rate": 4
        }
      ]
    }
  },
  "metadata": {
    "namespace": "teamname",
    "certificationFileName": "",
    "proxyUrl": {
       "type": "api",
       "host": "gateway-stage-core.optum.com",
       "domain": "external",
       "sub-domain":"",
       "env":"alpha",
       "namespace":"",
       "resource":"myapiresource2",
       "version":"v2"
    },
    "tags" : ["somestring1", "somestring2"],
    "override": {
      "autoMerge": true
    }
  }
}
```

### Credentials

Created but cannot be modified by self-service(byproduct of namespace creation), the SLO of the namespace will receive the credentials by secure email with this formatted resource:

```json
{
  "kind": "stargate-team",
  "spec": {
    "id": "",
    "credentials": [
      {
        "env": "prod",
        "jwtSecret": "",
        "jwtKey": "",
        "oauthClientSecret": "",
        "oauthClientId": ""
      },
      {
        "env": "nonprod",
        "jwtSecret": "",
        "jwtKey": "",
        "oauthClientSecret": "",
        "oauthClientId": ""
      }
    ]
  },
  "metadata": {
    "namespace": "teamname"
  }
}
```

## stargate-postback

This is an optional resouce you may include in your PR to recieve programmatic call backs keeping you in the loop on the results of your PR as it makes its way through self-service.

### Enable Stargate PostBack

```json
{
  "kind": "stargate-postback",
  "spec": {
    "postBackUrl": "https://stargate-selfservice-status-updates.optum.com/listener/v1"
  }
}
```

What the postback sends to your endpoint will look like these HTTP Bodies(JSON Content):

Prior to merge sanitize check(lets you know your PR was correct quickly):

```json
{
  "prNumber": 123,
  "status": 200,
  "preMerge": true
}
```

Post merge creation example(lets you know when its actually been processed):

```json
{
  "prNumber": 123,
  "status": 200,
  "preMerge": false
}
```

status can be: 200(success), 400(bad request), 401(unauthorized, meaning the person doing the pull request did not have AD groups necessary).
