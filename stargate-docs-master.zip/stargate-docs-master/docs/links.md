
## Support Tickets
Please open an issue in [Github](https://github.optum.com/APIGateway/support)

## For Questions
[Stargate Technical Support has a Flowdock](https://www.flowdock.com/app/uhg/api-gateway-evaluation)! Please direct all questions related to Stargate Integrations (no matter how app-specific) here, for the most responsive support.

If you're not on Flowdock yet - it's time [https://hubconnect.uhg.com/thread/95689](https://hubconnect.uhg.com/thread/95689)

## Email Distro list
<Stargate_API_Gateway_DL@ds.uhc.com>

## CORE Shared Gateway
(Core -> Core traffic and App-DMZ -> Core Traffic patterns)

Non-Prod: https://gateway-stage-core.optum.com/

Prod: https://gateway-core.optum.com/

## DMZ Shared Gateway
(Public Internet -> DMZ and Public Internet -> CORE and DMZ->DMZ)

Each DMZ shared proxy will have two VIPS which can be used to access the service. In terms of functionality, both are identical and both will be active at all times. The only determining factor in which to use, is where the consumer is located within the network.

### Public VIPS
Used when calling the DMZ proxy from the public internet or DMZ pres-layer

Non-Prod: https://gateway-stage.optum.com/

Prod: https://gateway.optum.com/

### Internal VIPS
Used when calling the DMZ proxy from within the UHG network

Non-Prod: https://gateway-stage-dmz.optum.com/

Prod: https://gateway-dmz.optum.com/

## OAUTH2.0 Token Generation Endpoints(Preferred - New):
|ENV|Network|URL|
|---|---|---|
|STAGE|CORE|`https://gateway-stage-core.optum.com/auth/oauth2/cached/token`|
|PROD|CORE|https://gateway-core.optum.com/auth/oauth2/cached/token|
|STAGE|DMZ-APP (for internal use)|https://gateway-stage-dmz.optum.com/auth/oauth2/cached/token|
|PROD|DMZ-APP (for internal use) |https://gateway-dmz.optum.com/auth/oauth2/cached/token|
|STAGE|DMZ-PUBLIC|https://gateway-stage.optum.com/auth/oauth2/cached/token|
|PROD|DMZ-PUBLIC|https://gateway.optum.com/auth/oauth2/cached/token|

## UI to view Proxy Services and Enabled Consumers
Data is the same regardless of datacenter

User/Password: readonly / readonly

|ENV |Network|ELR|CTC|
|---|---|---|---|
|STAGE | CORE| [https://konga-kong-gateway-stage.origin-elr-core.optum.com/](https://konga-kong-gateway-stage.origin-elr-core.optum.com/)|[https://konga-kong-gateway-stage.origin-ctc-core.optum.com/](https://konga-kong-gateway-stage.origin-ctc-core.optum.com/)|
|PROD|CORE|[https://konga-kong-gateway-prod.origin-elr-core.optum.com/](https://konga-kong-gateway-prod.origin-elr-core.optum.com/)|[https://konga-kong-gateway-prod.origin-ctc-core.optum.com/](https://konga-kong-gateway-prod.origin-ctc-core.optum.com/)|
|STAGE| DMZ|[https://konga-kong-gateway-stage.origin-elr-dmz.optum.com/](https://konga-kong-gateway-stage.origin-elr-dmz.optum.com/)|[https://konga-kong-gateway-stage.origin-ctc-dmz.optum.com/](https://konga-kong-gateway-stage.origin-ctc-dmz.optum.com/)|
|PROD| DMZ| [https://konga-kong-gateway-prod.origin-elr-dmz.optum.com/](https://konga-kong-gateway-prod.origin-elr-dmz.optum.com/)|[https://konga-kong-gateway-prod.origin-ctc-dmz.optum.com/](https://konga-kong-gateway-prod.origin-ctc-dmz.optum.com/)|

## Grafana API Dashboard URLs

|ENV |Network|URL|
|---|---|---|
|STAGE| CORE| [http://stargate-metrics-core-stage.optum.com](http://stargate-metrics-core-stage.optum.com)|
|PROD| CORE| [http://stargate-metrics-core-prod.optum.com](http://stargate-metrics-core-prod.optum.com)|
|STAGE| DMZ| [http://stargate-metrics-dmz-stage.optum.com](http://stargate-metrics-dmz-stage.optum.com)|
|PROD| DMZ| [http://stargate-metrics-dmz-prod.optum.com](http://stargate-metrics-dmz-prod.optum.com)|

## Splunk Dashboards
AD Group: SSMOSplunk_stargate_prod needed to view

Top API consumers can be seen on left hand side of the dashboard

|ENV|URL|
|---|---|
|STAGE| [https://phi-splunk.optum.com/en-US/app/optum_stargate/tanksi_mbo_dashboard_nonprod](https://phi-splunk.optum.com/en-US/app/optum_stargate/tanksi_mbo_dashboard_nonprod)|
|PROD| [https://phi-splunk.optum.com/en-US/app/optum_stargate/stargate_mbo_metrics](https://phi-splunk.optum.com/en-US/app/optum_stargate/stargate_mbo_metrics)|

## Jaeger OpenTracing
Stargate sends 10% of the requests to Jaeger.

|ENV|URL|
|---|---|
|STAGE|[http://opentracing-query-dev.optum.com/search](http://opentracing-query-dev.optum.com/search |
|PROD| Coming-soon |
