
Below are the logos that are free to use by other teams to represent Stargate within diagrams.

## Logo
![](assets/StargateLogo.png)

## Text Logo
![](assets/StargateText.png)

## Logo with Text
![](assets/StargateLogoText.png)
