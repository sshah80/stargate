
## Crossing network segments
If your API is hosted in a different network segment than the consumer, then Stargate
should be used to help the network traffic.

## Rate limiting
If your API has a limit that it can handle and needs to implement that, then Stargate
should be used to help protect your API.

## Browser Based Authentication
If you require a form of user authentication, and want to have user authentication using MSID, OptumID, or HealthSafeID for your API, then Stargate should be used to help protect your API.

## Programmatic authentication
If you require a form of programmatic authentication between applications, then Stargate can be used to manage this and protect your API.

## Request/Response Size limiting
If you want protection against a large request or response payloads then Stargate should be used to
help protect your API.
