# Support Playbook

## Protection Points
* Traffic allowed only from 3 IP addresses (AWS VPC Egress, blocked at PaloAlto Perimiter FW)
  * 35.171.51.179
  * 52.207.105.202
  * 52.72.202.17

 * AWS ShieldAdvanced providing DDOS protection Cloudfront and S3
 * AWS WAF infront of AWS API Gateway
 * F5 ASM WAF tuned for DDOS sensitivity (F5 Team in front of Stargate)
 * CloudFront in AWS geofenced US traffic only (AWS Sheild in ftont of Microsite and AWS API Gateway)
 * Lamdas Protected within AWS VPC
 * Dedicated HHSP vip for stargate - traffic isolation and kill switch
 * Dedicated Stargate API cluster - traffic isolation
 * Re-captcha providing protection from bots (HHSP Portal)
 * End to End encryption of API traffic from source to database

## Emergency Cutoff for gateway-covid19
* Any need to completely shut down this service into our network can be accomplished by contacting F5 to disable the VIP setup particularly for this service. Use tech.optum.com to disable, need incident change. Send connection resets.
* Palo Alto Firewall can lock down traffic.  Contact Firewall team, Laurence Prine, Scott A Long, Alex Edwards.
* Shutoff routes in openshift - Stargate Team
* Shutoff Stargate - Stargate Team

## Rate limiting
* Stargate can throttle traffic coming from this source
 * Stargate would return 429 responses
 * Response time to make change is almost immediate

## Threat Scenarios

### Core System Protection
* **Condition**: 
  * Core systems(Stargate infra) under stress.
* **Detection**: Indication of core system contention/degredation will appear to gateway as:
  * Increase in timeout above baselines 2sec for connection 9 second for response.
  * Network errors, connection resets on downstream routes
  * Direct notification from downstream application
* **Response**: 
  * Application of rate limiting at AWS API GW to impacted proxies until symptoms resolve.
  * Performance testing (4/11) shows scaling HHSP API pods offers no improvement of capacity.
 
### DDOS Attacks
* **Condition**: 
  * High volume of traffic (extreme case, 3k tps)
* **Detection**: 
  * Abnormal spike in traffic (splunk logs, dashboard)
* **Response**: 
  * rate limit as close to the edge of the network (in order protections below)
  * protection at the Palo Alto Firewall (warroom calling in firewall team)
  * F5 can also rate limit (warroom calling in F5 team to manually add rate limit, Marcus Boog)
  * impose rate limits on authenticated traffic (allowing some traffic but throttling)
  * rate limits on specific source IP (spoofed IPs potentially)

### High volume of 500 type errors
* **Condition**: 
* **Detection**: 
  * Abnormal spike in 500 errors (5%)
* **Response**: 
  * Detected by Grafana alerts, sent to API provider, Dashboard created for the API provider, also tuned to send to Stargate DL
  * Alert to pager duty for consumer and stargate

### High volume of 401 errors
* **Condition**: 
  * Malicious attacks from non-authenticated users
  * Expired tokens also get 401 errors so could be issue with app (oauth implementation)
* **Detection**: 
  * Abnormal spike in 401 errors (5%)
* **Response**: 
  * rate limit as close to the edge of the network (in order protections below)
  * protection at the Palo Alto Firewall (warroom calling in firewall team, Alex Edwards)
  * F5 can also rate limit (warroom calling in F5 team to manually add rate limit)
  * impose rate limits on authenticated traffic (allowing some traffic but throttling)
  * rate limits on specific source IP (spoofed IPs?)
 
### Malicious attack
* **Condition**: 
  * Real hack coming in mimicking authenticated user
  * e.g. root kit attack, nosql injection attack
* **Detection**: 
  * Trigger AWS WAF (alert?)
  * Trigger ASM WAF (in ASM logs, contact ASM team, Stargate is not alerted)
* **Response**: 
  * contact AWS WAF team with data to help tune
  * tune ASM WAF
  * if in immediate danger, contact SIR, follow Emergency Cutoff for gateway-covid19
  
### Token Abuse
* **Condition**: 
  * Attacker finds non-cached token endpoint 
* **Detection**: 
  * Abuse detected by Splunk logs/alerts to non-cached token endpoint
* **Response**: 
  * set rate limit against AWS consumer on the non-cached endpoint in stargate by IP Address
