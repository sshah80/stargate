
### Steps for API Provider
1. [Provision a nonprod Stargate Proxy](firststeps.md#step-3-proxy-definition) equivalent to the existing Layer7 service to be migrated (this step can be done without impacting the existing Layer7 service)
2. Modify existing provider-side validation FROM Layer7 SAML TO [Stargate JWT](stargate-security.md#provider-side-stargate-jwt)
3. [OPTIONAL] If validating the Client ID passed in the Layer7 SAML to determine Consumer identity, switch to Stargate Consumer ID, passed in `x-consumer-id` header
4. [OPTIONAL] If consumer Correlation ID is followed, switch to get it from **optum-cid-ext** header with hyphen (In Layer7, it is optum_cid_ext with underscore)
5. Test and Validate
6. Complete [API Certification](https://www.optumdeveloper.com/content/odv-optumdev/optum-developer/en/getting-started/apis/api-self-attestation.html) At a minimum meet these [requirements](layer7-stargate-migration.md#layer-7-migration-requirements-for-certification)
7. Deploy Production Stargate proxy

### Image of steps needed
![](assets/layer7-provider-migration.png)
