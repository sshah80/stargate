
This section provides background on CORS, and how it is used through Stargate for browser-based API calls


## What is CORS?
CORS is a security mechanism which browsers use to determine if they are allowed to execute a pending ajax call. Browsers use CORS to protect users from malicious javascript execution.

Let's look at a basic example to understand what that really means:
 - Beth is an average user of a UHG site called `claim-checker.uhc.com` . She uses this site to update a pending claim
 - When beth reaches this site, she is prompted to login with OptumID credentials
 - In the background, these credentials are used to generate a pingfederate access_token, which is cached in her browser.
 - When Beth then goes to update the status of her claim, an API call using HTTP `PUT` is made from the javascript in her browser to a Stargate-protected API to affect the claim data
 - The pingfederate access_token is used to authenticate this API call to Stargate, by adding it to the `authorization` header

Now suppose Beth is the victim of a phishing attempt.
  - Beth receives an email which is designed to appear like it's from UHC, and directs her that urgent action is needed on her account. This email contains a "helpful" link to the site
  - When beth clicks the link, she is directed to `claim-checker.uhc.co` - which is an exact copy of the real `claim-chcker.uhc.com`, with additional Javascript code to sniff any response to the claim API - and send it to the malicious actor's database
  - Beth is prompted for her OptumID creds, and upon logging in is issued her access_token and successfully authenticates to the Stargate-protected API - so her claim data is compromised.

Now, let's see what CORS can do to help. We'll take the same phising scenario, but now add CORS logic.
 - Beth reaches the malicious `claim-checker.uhc.co`, and once again successfully logs in with OptumID, generating her pingfederate access_token
 - This time, when Beth clicks the link which calls the Stargate-protected claim-checker API - a few things happen before the `PUT` is made
 - First, the browser initiates the CORS pre-flight check. This is an `OPTIONS` http method call to the same URL as the intended `PUT` with a special header called `origin`
 - This `origin` header is populated by the browser itself, and contains the current domain the user is browsed to. In this example, the header looks like this `origin: https://claim-checker.uhc.co`
 - When Stargate sees this pre-flight HTTP `OPTIONS` request, it checks to see if the origin `https://claim-chcker.uhc.co` is listed (in it's internal config for that service) as a valid origin
 - Finding it is not listed, Stargate responds to this pre-flight call and **omits** a header called `Access-Control-Allow-Origin`
 - This header would normally echo back the `origin` offered in the request, to confirm it is accepted (more on that in later sections)
 - When the browser sees that Stargate's response to the `OPTIONS` pre-flight check does not contain it's origin in the `Access-Control-Allow-Origin` header, it knows that the call it is trying to make isn't coming from the correct domain - and blocks the `PUT` from occurring
 - Success! Beth's data is safe.

Great! Now that we know what CORS is for, let's dive into how it works

## How does CORS work?
For most ajax calls, CORS works in two phases.
 1. The pre-flight `OPTIONS` call
 2. The actually API call

However, **not all calls run a preflight**. The specific conditions under which a preflight is sent are:
* If the request uses any of the following methods:
  * PUT
  * DELETE
  * CONNECT
  * OPTIONS
  * TRACE
  * PATCH
* Or if, apart from the headers set automatically by the user agent, the request contains any of the following headers
  * Accept
  * Accept-Language
  * Content-Language
  * Content-Type (note additional requirements below)
  * DPR
  * Downlink
  * Save-Data
  * Viewport-Width
  * Width
* Or if the Content-Type header has a value OTHER THAN the following:
  * application/x-www-form-urlencoded
  * multipart/form-data
  * text/plain
* Or if one or more event listeners are registered on an XMLHttpRequestUpload object used in the request.
* Or if a ReadableStream object is used in the request.

For transactions which do not meet those conditions, CORS only runs on the API call itself

### CORS Preflight
So far, we've only discussed `origin` restrictions, but the pre-flight phase can actually governs several properties of the API request.
There are several headers other than `origin` which a browser may issue in a preflight check. Each of these is asking the server "is X allowed?", prior to sending the actual request - though only `origin` is required.

The full list of pre-flight **request** headers is:

| Request Header | Example Value | Description |
| ------ | ------ | ------ |
| `Origin` (required) | `https://my-domain.com` | The current domain which the user is browsed to |
| `Access-Control-Request-Method` | `POST` | The HTTP method to be used on the pending request |
| `Access-Control-Request-Headers` | `x-myheader, Content-Type`| A list of non user-agent headers which will be passed in the pending request |

The full list of pre-flight **response** headers is:

| Response Header | Example Value | Description |
| ------ | ------ | ------ |
| `Access-Control-Allow-Origin` | `https://my-domain.com`  | Response header which indicates the domain allowed for this transaction. Can be either a FQDN, `*` or `null`|
| `Access-Control-Request-Method` | `POST, GET, OPTIONS` | The complete list HTTP methods supported by the API call |
| `Access-Control-Request-Headers` | `x-myheader`, `Content-Type`| Will echo back only the supported headers from `Access-Control-Request-Headers`|
| `Access-Control-Allow-Credentials` | `true` | Indicates whether or not credentials should be sent on the API call. |
| `Access-Control-Max-Age` | `3600` | A value in seconds which tells the browser how long it can cache the pre-flight results for |

Let's break down the `origin` interaction a little further, as this is the most common filter used in CORS.
`Origin` -> `Access-Control-Allow-Origin:` When the browser sends the `Origin` header, either in the pre-flight or API call, one of four responses are possible.
Let's say the browser sends a header `origin: my-api.optum.com` in the pre-flight:

| Response Header | Result in Browser   |
| ------ | ------ |
| `Access-Control-Allow-Origin: *` | Everything is allowed, therefore the transaction proceeds. This is dangerous practice, as it defeats the point of CORS in the first place by allowing every origin to send transactions to the API  |
| `Access-Control-Allow-Origin: null` | Nothing is allowed, therefore the transaction is canceled by the browser |
| `Access-Control-Allow-Origin: my-api.optum.com` | Server has confirmed to the browser that the specific domain `my-api.optum.com` is allowed, therefore transaction proceeds |
|  | If header is not present at all in response, the specific domain `my-api.optum.com` is not allowed, therefore the transaction is canceled by the browser|

### CORS API Call
Regardless of whether or not there was a pre-flight check (based on conditions defined above), CORS will always run on the API call itself. The browser accomplishes this by injecting headers into the Stargate-protected API call sent from the javascript.

The full list cors of API call **request** headers is:

| Request Header | Example Value | Description |
| ------ | ------ | ------ |
| `Origin` (required) | `https://my-domain.com` | The current domain which the user is browsed to|

The full list cors of API call **response** headers is:

| Response Header | Example Value | Description |
| ------ | ------ | ------ |
| `Access-Control-Allow-Origin` | `https://my-domain.com`  | Response header which indicates the domain allowed for this transaction. Can be either a FQDN, `*` or `null`|

## Stargate Support for CORS
Stargate is configured to handle CORS requests on behalf of the protected API. For APIs which require CORS (normally those using [user auth security patterns](stargate-security.md)), Stargate stores a set of static CORS configs defined by the API provider for each of the 5 CORS-controlled request properties.

These properties are:

| Response Header | Example Value | Description |
| ------ | ------ | ------ |
| `Allowed Origins` | `https://my-domain.com`, `https://my-other-domain.com`,`.*[.]optum[.]com`  | Example allowing both `my-domain` origins explicitly, and all subdomains of `.optum.com` by regular expression|
| `Allowed Method` | `POST, GET, OPTIONS` | The complete list HTTP methods supported by the API call |
| `Allowed Headers` | `x-myheader`, `Content-Type`| Allow additional request headers `x-myheader` and `Content-Type`. Most providers choose to leave this field empty, and rely on upstream parsing to control request headers|
| `Allow Credentials` | `true` | Indicates whether or not credentials should be sent on the API call. When using Stargate, this should **always** be configured as `true`, because we're always going to be authenticating to the proxy|
| `Max-Age` | `3600` | Tells the browser to cache these results for 1 hour |

Based on these properties, Stargate will then handle all the CORS involved in a standard API call. An example flow is:

![Stargate CORS](https://github.optum.com/APIGateway/stargate-docs/blob/master/docs/assets/Stargate%20CORS.png?raw=true)
