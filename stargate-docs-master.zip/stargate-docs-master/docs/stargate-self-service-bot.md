
The code for the bot is found [here](https://github.optum.com/APIGateway/stargate-self-service-agent)

## Github Self-Service comments as commands

You can use the following commands as comments in your pull request.

| Command | Description |
|----------|------------|
| validate | This command will kick off Self-Service request validation in the event the application was down during your PR and could not evaluate it during that real-time request. |
| i approve | This command will be used by Stargate self-service admins to approve proxy requests that require exceptions to be granted. |
