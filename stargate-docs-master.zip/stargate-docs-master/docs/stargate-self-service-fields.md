
### Top level fields

```json
{
  "kind": "",
  "action": "",
  "spec": {},
  "metadata": {}
}
```

| Element | Description |
|---|---|
| kind | The type of resource you are working with: stargate-namespace, stargate-proxy . |
| action | The action to take on the resource: create,update,delete. |
| spec | This object holds specification data regarding your Stargate resource. |
| metadata | This object will hold metadata regarding your Stargate resource. |

## stargate-namespace

### stargate-namespace spec

```json
{
"kind": "stargate-namespace",
...
  "spec": {
    "namespace": "teamname",
    "sloEmail": "bossman@optum.com",
    "teamEmailDL": "TeamDistroList@optum.com",
    "askId": "UHGWM-45675555",
    "adGroup": "myexample_adgroup",
    "nonProdAdGroup": "non-prod-ad-group"
  }
...
}
```

| Element | Description |
|----------|------------|
| spec.namespace | This will be your official acronym on Stargate. Be sure to pick something short and clean that yourself and all colleagues will remember and acknowledge. |
| spec.sloEmail | The email of the person responsible for this namespace and all resources contained within it post creation. |
| spec.teamEmailDL | A distribution list email of all colleagues involved supporting this namespace. This email distribution list is likely to recieve alerts anytime the API services hosted on this namespace face issue. |
| spec.askId | Internal company accounting id essentially, every namespace needs an ask id. |
| spec.adGroup | This provides a namespace its security controls. The person creating pull requests against Stargate self-service needs to possess the ad group of the namespace to modify or create new resources within the namespace itself. |
| spec.nonProdAdGroup | This provides the namespace an optional non-prod security control group. The person creating pull requests with this group will only be able to exclusively work with non-prod stargate proxies. |

### stargate-namespace metadata

```json
{
"kind": "stargate-namespace",
...
  "metadata": {
    "tags": [
      "somestring1",
      "somestring2"
    ],
    "resendCredsToSlo": true,
    "rotateNonProdOauth2Credentials": true,
    "rotateNonProdJwtCredentials": true,
    "rotateProdOauth2Credentials": true,
    "rotateProdJwtCredentials": true
  }
...
}
```

| Element | Description |
|----------|------------|
| metadata.tags | A list of string section you can populate with anything you like that maintains valid json. Notes perhaps. Do note the field will populate with a simple splunk query and link to your grafana dashboard for your API service after stargate proxy creation. |
| metadata.resendCredsToSlo | Boolean when set to true on namespace ```"action": "update"``` will redeliver namespace credentials to the SLO of the namespace. The field will not persist post processing.|
| metadata.rotateNonProdOauth2Credentials | Boolean when set to true on namespace ```"action": "update"``` will rotate Non-Production OAuth2 Credentials and re-deliver namespace credentials to the SLO of the namespace. The field will not persist post processing. <br /><br />**Warning: Use with caution as it will break any applications using the older credentials**|
| metadata.rotateNonProdJwtCredentials | Boolean when set to true on namespace ```"action": "update"``` will rotate Non-Production JWT Credentials and re-deliver namespace credentials to the SLO of the namespace. The field will not persist post processing. <br /><br />**Warning: Use with caution as it will break any applications using the older credentials**|
| metadata.rotateProdOauth2Credentials | Boolean when set to true on namespace ```"action": "update"``` will rotate Production OAuth2 Credentials and re-deliver namespace credentials to the SLO of the namespace. The field will not persist post processing. <br /><br />**Warning: Use with caution as it will break any applications using the older credentials**|
| metadata.rotateProdJwtCredentials | Boolean when set to true on namespace ```"action": "update"``` will rotate Production JWT Credentials and re-deliver namespace credentials to the SLO of the namespace. The field will not persist post processing. <br /><br />**Warning: Use with caution as it will break any applications using the older credentials**|

## stargate-proxy

### stargate-proxy spec

```json
{
  "kind": "stargate-proxy",
  ...
  "spec": {
    "name": "my.api.stage",
    "routeId": "",
    "serviceId": "",
    "url": "https://hostname-of-my-api-server:443/root/path",
    "proxyUrl": "",
    "auth": {"type": "oauth2", "grant": "client_credentials"},
    "connectTimeout": 2000,
    "readTimeout": 9000,
    "writeTimeout": 9000,
    "mtlsUpstreamRouting": false,
    "authorizedConsumers": [
      "upm",
      "opi",
      "myuhc"
    ]
  }
  ...
}
```

| Element | Description |
|----------|------------|
| spec.name | The human readable name of your api service. All lowercase and period delimited. |
| spec.routeId | **Autopopulated** after creation. It is used on update/delete, you never need to modify this or set it yourself. |
| spec.serviceId | **Autopopulated** after creation. It is used on update/delete, you never need to modify this or set it yourself. |
| spec.url | This is the field to set to the full path of your API service. <br /><br />**Recommended: TLS encrypted APIs** |
| spec.proxyUrl | **Autopopulated** after creation. This field is read only, **DO NOT POPULATE**, its derived based on data existing in metadata.proxyUrl element and can be seen after self-service evaluates your stargate-proxy request. |
| spec.auth | **See below** |
| spec.connectTimeout | The time Stargate will wait for the TCP handshake to complete in milliseconds. <br /><br />**Required** Standard: 2000 |
| spec.readTimeout | The time Stargate will wait on the API Service to respond by in milliseconds. <br /><br />**Required** Standard: 9000 |
| spec.writeTimeout | The time Stargate will wait on the API Service to accept request packets in milliseconds. <br /><br />**Required** Standard: 9000 |
| spec.authorizedConsumers | The list of programmatic consumers(namespaces) authorized to call your API service through Stargate.<br/><br/>**Default**: Set to an array of size(1), containing the namespace which owns the proxy|
| spec.mtlsUpstreamRouting | Boolean (`true`/`false`); Enable [Stargate Provider-Side MutualTLS Routing](stargate-security.md#provider-side-mutualtls), in addition to [Stargate Provider-Side JWT](stargate-security.md#provider-side-stargate-jwt)<br/><br/>**Default**: `false`|
### stargate-proxy spec auth

```json
{
  "kind": "stargate-proxy",
  ...
  "spec": {
    ...
    "auth": {"type": “jwt”, “alg”:”hs256”}
    ...
  }
  ...
}
```

-- or --

```json
{
  "kind": "stargate-proxy",
  ...
  "spec": {
    ...
    "auth": {"type": "oauth2", "grant": "client_credentials"}
    ...
  }
  ...
}
```

| Element | Description |
|----------|------------|
|spec.auth.type|The type of client side authentication you would like to your stargate proxy. Types are oauth2 and jwt. <br /><br />**Recommended: jwt** |
|spec.auth.alg|This field is only used for jwt and specifies the algorithm to be used.  <br /><br />**Only hs256 is supported at this time.**|
|spec.auth.grant|This field is only used with auth type oauth2 and specifies the grant to be used.|

### stargate-proxy spec options

```json
{
  "kind": "stargate-proxy",
  ...
  "spec": {
    ...
    "options": {
      "specExpose": "http://optum.com/my/service/path/v1/spec.json",
      "cors": [".*[.]optum[.]com", "http://localhost", "https://myuhc.com"],
      "rateLimit": 33,
      "requestSizeLimiter": 2,
      "responseSizeLimiter": 5,
      "rateLimitByConsumer": [
        {
          "consumer": "upm",
          "rate": 15
        },
        {
          "consumer": "myuhc",
          "rate": 2
        }
      ]
    }
  }
  ...
}
```

Note that these are all optional.

| Element | Description |
|----------|------------|
| spec.options | The list of custom functionality your proxy can support ontop of the gateway defaults(500 tps rate limit by default globally enabled on gateway). These do not need to be set unless explicity needed. |
| spec.options.specExpose | A link to your Open API Spec or WSDL or WADL. This will expose on your proxyUrl path + /specz appended to the end of the url without required auth for the viewing of your services specification documentation. |
| spec.options.cors | A string list of allowed CORS origins . Wildcard all optum subdomains ex: ```.*[.]optum[.]com``` , other values ```http://localhost``` development testing, ```https://myuhc.com``` fully qualified origin. [Read more on CORS here](cors.md#what-is-cors)  |
| spec.options.rateLimit |A proxy ratelimit that will be imposed on all consumers in transactions per second. |
| spec.options.requestSizeLimiter | The size in MB this proxy will allow on request. |
| spec.options.responseSizeLimiter | The size in MB this proxy will allow on api service response(caveat being API Service needs to return content-length header for this to work). |
| spec.options.rateLimitByConsumer | A proxy ratelimit in transactions per second that will be imposed on a specific consumer if needed. |

### stargate-proxy metadata

```json
{
  "kind": "stargate-proxy",
  ...
  "metadata": {
    "namespace": "teamname",
    "certificationFileName": "",
    "proxyUrl": {
        ...
    },
    "tags" : ["somestring1", "somestring2"],
    "override": {
      ...
    }
  }
}
```

| Element | Description |
|----------|------------|
| metadata.namespace | This must match your namespace resource, this helps us maintain who ownes what API services hosted on stargate. |
| metadata.certificationFileName | File name of Taxonomy Team approved OpenAPI spec. Only needed for production proxy. |
| metadata.proxyUrl | This is the intake object that defines the spec.proxyUrl after processing, this object determines your proxy url. |
| metadata.tags | A list of string section you can populate with anything you like that maintains valid json. Notes perhaps. Do note the field will populate with a simple splunk query and link to your grafana dashboard for your API service after stargate proxy creation. |
| metadata.override | This object holds any overrides that should be applied to the proxy resource |

### stargate-proxy metadata.proxyUrl

```json
{
  "kind": "stargate-proxy",
  ...
  "metadata": {
    "proxyUrl": {
       "type": "api",
       "host": "gateway-stage-core.optum.com",
       "domain": "external",
       "sub-domain":"",
       "appname":"",
       "env":"alpha",
       "namespace":"",
       "resource":"myapiresource",
       "version":"v1"
    }
    ...
  }
}
```

<table>
   <tr>
      <th>Element</th>
      <th>Description</th>
      <th>Required when</th>
   </tr>
   <tr>
      <td>metadata.proxyUrl.host</td>
      <td>This is the gateway domain you intend to publish to. Be sure to publish to the correct gateway!<br/>Default: gateway-stage-core.optum.com
      </td>
      <td style="color:#627D32; font-weight:bold">Always</td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.type</td>
      <td>This field deonates the type of API Proxy to be created. Accepted values are `api` for a <span style="font-weight:bold; color:#C25608">Standard Proxy</span>, and `app`, which denotes a <a style="font-weight:bold; color:#A32A2E"><a href="https://api-docs.optum.com/standards/api-naming/#302-must-point-to-point-apis-use-app">Peer-to-Peer Proxy</a>.<br/>Default: api</td>
      <td style="color:#627D32; font-weight:bold">Always</td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.domain</td>
      <td>Chosen from the list of valid API Taxonomy domains. See <a href="https://github.optum.com/raw/API-Certification/Taxonomy-Review/master/scripts/domain-taxonomy.json">Taxonomy-JSON</a> domain name elements for options.</td>
      <td style="color:#C25608; font-weight:bold">Standard 'API' Proxy</td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.sub-domain</td>
      <td>Chosen from the list of valid API Taxonomy sub-domains(which are nested under a domain). See <a href="https://github.optum.com/raw/API-Certification/Taxonomy-Review/master/scripts/domain-taxonomy.json">Taxonomy-JSON</a> subdomain name elements within the domain of choice for options. This field is optional or required empty for many domains.</td>
      <td style="color:#422C88; font-weight:bold">Optional for <span style="font-weight:bold; color:#C25608">Standard 'API' Proxy</span></td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.env</td>
      <td>Lower logical environment (dev, test, stage, etc) of your API Proxy</td>
      <td><span style="color:#627D32; font-weight:bold">Always in Non-Production</span><br/><span style="color:#FF0000; font-weight:bold">Disallowed in Production</span></td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.appname</td>
      <td>URI path element appearing after `env` and before `version` on peer-to-peer proxies</td>
      <td style="color:#A32A2E; font-weight:bold">Peer-to-Peer 'APP' Proxy</td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.namespace</td>
      <td>URI path value to come after your `domains` and before your `resource`, does not have to be the same as your stargate namespace</td>
      <td style="color:#422C88; font-weight:bold">Optional for <span style="font-weight:bold; color:#C25608">Standard 'API' Proxy</span></td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.resource</td>
      <td>The RESTful api resource value, URI element populated before version</td>
      <td style="color:#422C88; font-weight:bold">Optional for <span style="font-weight:bold; color:#C25608">Standard 'API' Proxy</span></td>
   </tr>
   <tr>
      <td>metadata.proxyUrl.version</td>
      <td>API service version must conform to `v{major}[.minor]` syntax.<br/>Default:`v1</td>
      <td style="color:#627D32; font-weight:bold">Always</td>
   </tr>
</table>

### stargate-proxy metadata.override

```json
{
  "kind": "stargate-proxy",
  ...
  "metadata": {
    "override": {
      "autoMerge": true,
      "certificationCheck": true,
      "versionCheck": true,
      "pathSpecificityCheck": true,
      "timeoutCheck": true,
      "rootDomainCheck": true
    }
    ...
  }
}
```

| Element | Description |
|----------|------------|
| metadata.override.autoMerge | Boolean can be set to false to disable processing of pull request automatically if valid. |
| metadata.override.certificationCheck | Boolean can be set to false, if approved by a stargate self-service admin, this allows an admin to PR a resource and skip checking the taxonomy repo for api certification(which would require agreement from api governance and taxonomy team) for production proxies. |
| metadata.override.versionCheck | Boolean can be set to false, must be approved by a stargate self-service admin through certification exception, this allows logic to skip validating the version of a proxy is present or a standard valid format. |
| metadata.override.pathSpecificityCheck | Boolean can be set to false, must be approved by a stargate self-service admin through certification exception, allows creation of a `metadata.proxyUrl.type == api` proxy without either `metadata.proxyUrl.namespace` or `metadata.proxyUrl.resource` set|
| metadata.override.timeoutCheck | Boolean can be set to false, must be approved by a stargate self-service admin, this allows logic to skip checking the connection and read write timeout settings on a proxy. This comes in handy for teams with proper exceptions from the api certification team for long running APIs or for websocket traffic. |
| metadata.override.rootDomainCheck | Boolean can be set to false, must be approved by a stargate self-service admin, this allows logic to skip checking the spec.url root domain on a proxy. This comes in handy for teams to route to api services hosted on internal domains that have not made the whitelist(currently ```optum.com,uhg.com,uhc.com```) yet. Stargate does not allow reverse proxying to API services outside our network. |
| metadata.override.productionEnvCheck | Boolean can be set to false, must be approved by a stargate self-service admin, this allows setting the `metadata.proxyUrl.env` field on a production proxy.|
