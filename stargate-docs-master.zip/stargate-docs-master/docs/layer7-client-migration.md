
## Steps to Migrate an OAuth2 Client Credentials Protected Service
Stargate and Layer7 both support OAuth Client Credentials, implemented per [RFC 6749](https://tools.ietf.org/html/rfc6749). The only real difference in behavior between the two gateways is error handling for exceptions like timeouts, layer-4 failures, etc.

## Client Migration of OAuth2 Client Credentials
1. Obtain new credentials (Namespace in [self-service](stargate-self-service.md))
2. Change [oauth endpoint](links.md#oauth20-token-generation-endpoints)
3. <span style="color:red">OPTIONAL</span> Remove request headers `Actor` and `Scope`. These are not required by Stargate, and are not logged.
4. <span style="color:red">OPTIONAL</span> Change to [JSON Body](stargate-security.md#token-request)
5. <span style="color:red">OPTIONAL</span> Set the Correlation ID value to **optum-cid-ext** header with hyphen (In Layer7, it is optum_cid_ext with underscore)
6. Change API Endpoint
7. Code towards different [set of errors](stargate-error-codes.md).

### Image of steps needed
![](assets/layer7-client-migration.png)
