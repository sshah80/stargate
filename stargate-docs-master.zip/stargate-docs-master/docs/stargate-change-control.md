
This section provides details on Stargate's production change control policy.

## Change Control Requirements
In an effort to minimize change process overhead, Stargate has structured it's policy to exempt changes which are managed via [Self-Service request](stargate-self-service.md).

The first step to determining the requirements for a Stargate resource change is to identify the status of the change: **Exempt**, or **Non-Exempt** according to the following definitions:


| Exempt Change                    | Definition                                                                                         |
|----------------------------------|-----------------------------------------------------------------------------------------------------|
| NonProd Resource Management        | All Stargate Resource Management in the Non-Production environments is considered Exempt  |
| Self-Service Resource Management       | All Production Self-Service resource creates, updates and deletes. Including namespace/team   |
| Manual Resource Management **Non-Live** | All non-Self-Serviceable changes to production services which are not accepting live traffic (including new service creation)  | 

| Non-Exempt Change                    | Definition                                                                              |
|----------------------------------|-----------------------------------------------------------------------------------------------------|
| Manual Resource Management **Live** | All non-Self-Serviceable changes to production services which are  accepting live traffic  | 

### Exempt Changes
Exempt changes are **not considered controlled changes to Stargate**, and the Stargate CI may not be added to as an Affected CI, assigned a CHG, or assigned a CHGTSK for these changes.

Change control should be applied and managed at the disgression of the API Provider.

### Non-Exempt Changes
Non-Exempt changes require a change ticket be submitted to track the work.

The change ticket should be submitted in this format:


- **Scheduling** 
  - Changes should be scheduled after 9:15PM CST (10:15PM CST during Peak Season) 
- **Assignment Group**
  - Change ticket should be assigned to the requesting team's assignment group (your group)
- **Affected CIs**
  - "Stargate API Gateway" 
  -  requesting team's CI (your CI)
- **Planning Section**
  - Pre-Implementation test plan
    - What you did to test the changes against the nonprod environment
  - Implementation plan
    -  If you require engineering support, include "Stargate engineer will execute changes listed in assigned change task"
  - Validation plan
	- What you will do to test the change once it is complete
  - Backout Plan
    - include "Stargate engineer will rollback changes listed in assigned change task"
    - Also include what you will do to validate that the changes have been successfully rolled back 
- **Change Task**
  - Assign this task to the group "Stargate API Gateway"
  - Include a description of the request AND the [Git Issue](https://github.optum.com/APIGateway/support) in which the work is defined, in this Task.
