
## Migration paths from Layer 7
* REST or SOAP service with supported Stargate auth pattern - Move to Stargate with minimal change
* REST service with Non supported Stargate auth pattern - update to [Stargate supported auth pattern](stargate-security.md) and move to stargate
* Soap service with non supported auth pattern
    * option 1: Change to [Stargate supported auth pattern](stargate-security.md) and move to Stargate
    * option 2: Move to Datapower with minimal change
  
## Clarification on Mutual TLS pattern
A Soap service using a MTLS pattern can currently be moved to Datapower with no change.  Stargate support for client side MTLS will be coming in a future release however and can be used without change but there are currently no guarantees on a release date.  Our estimate however would be around mid April 2020 for release.  

## PADU for APIs
Please review the current [PADU](https://github.optum.com/EAIP/strategy-and-practices/blob/master/PADU.md) descriptions to understand what is asked of an API to be preferred.

<h1>***Important Dates relating to End of Life for Layer7***</h1>

##    Layer7 will be decommissioned in August, 2020
##    Providers by 5/31/2020 Must:
        - Migrate their Layer7 Proxies to Stargate
        - Work with their consumers to point their code to the new Stargate Endpoint##
        
##      Submit Request to decommission Layer7 Proxies

- After consumers have been migrated off a Service(s) the team should submit
       
* * [Layer7 Service Decommission Request](https://servicecatalog.uhc.com/sc/catalog.product.aspx?parent_category_id=_X_&category_id=Platforms&product_id=API_Security_Services_Layer7_DataPower).
 
        - More than one Proxy can be requested per Request.
 
        - Layer7 Team will then assign the ticket, and the person assigned will ask that the Requestor create a Change Ticket with a task for the Layer7 team which specifies the proxies to be decommissioned. 
 
        - A date will then be scheduled for the decom to happen.  The Layer7 resource will ask for this and provide what is needed to be done by the requestor.
       
##    Layer 7 Production Cluster 1 on 2/29/2020 will no longer have Vendor Support
         - Layer7 Production 1 Cluster will not be shutdown
         - Support will be best effort by Layer7 Ops Team
         - Providers are encouraged to fast-track the migration of any Proxy defined on:
           - api.optum.com
           - api-int.optum.com
           - api-int-b.uhc.com
           - trustbroker-svcs.optum.com

## Layer 7 migration requirements for certification

### Lift and Shift
- A <b>Lift and Shift API</b> is defined as follows:
    - No API contract changes are being made to the existing service.
    - No additional endpoints are being added to the service.
    - No changes to the data model being sent in or out of the service.
- Must use [functional naming schema](https://api-docs.optum.com/standards/api-naming/#223-must-use-functional-naming-schema-for-proxy-urls).
- Must include specific [metadata](https://api-docs.optum.com/standards/meta-information/#219-must-contain-lift-and-shift-meta-information).
- Each service must provide a required Open API Spec or in rare cases where an OAS cannot be created such as with a SOAP service, then a [meta-data document](https://github.optum.com/API-Certification/Taxonomy-Review/tree/master/non-oas) for consumption with the [explorer](https://api-explorer.optum.com/) <sup>(Chrome only)</sup>.
- A [partial Open API Spec](https://github.optum.com/API-Certification/Sample-API/blob/master/docs/templates/partial-oas.yaml) is not desired but eligible in the case of an old framework that cannot produce the required OAS.  The spec must still provide all metadata, open api extensions, and paths, but may be missing request and response models.  All automated governance checks must still pass on this OAS document.
- Service published to [API explorer](https://api-explorer.optum.com/) <sup>(Chrome only)</sup>. This is an automated feature of going through normal [Taxonomy Review Process](https://github.optum.com/API-Certification/Taxonomy-Review#taxonomy-review).
- No exception is necessary and it will automatically be marked as a Unacceptable API.

### API with changes
- Must use [functional naming schema](https://api-docs.optum.com/standards/api-naming/#223-must-use-functional-naming-schema-for-proxy-urls).
- Each service must provide a required Open API Spec or in rare cases where an OAS cannot be created such as with a SOAP service, then a [meta-data document](https://github.optum.com/API-Certification/Taxonomy-Review/tree/master/non-oas) for consumption with the [explorer](https://api-explorer.optum.com/) <sup>(Chrome only)</sup>.
- Service published to [API explorer](https://api-explorer.optum.com/) <sup>(Chrome only)</sup>. This is an automated feature of going through normal [Taxonomy Review Process](https://github.optum.com/API-Certification/Taxonomy-Review#taxonomy-review).
- The service must meet all [API Standards](https://api-docs.optum.com/standards/introduction/) or an [exception](https://github.optum.com/API-Certification/Taxonomy-Review/blob/master/exceptions/README.md) is needed to proceed.

### SOAP Service
- Recommend carrying over as a Lift and Shift.
- Must follow HTTP authorization patterns. SOAP specific auth patterns such as SAML or WS-* are not supported.
