# Stargate

### [Get Started](https://stargate-docs.optum.com/firststeps/)
Go [here](https://stargate-docs.optum.com/firststeps/) to get started working with the Stargate API Gateway.
