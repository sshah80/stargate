
## What is the process around getting Stargate support?

### Desired primary approach

Do the tools and documentation solve the problem?

1. Transaction diagnosis question: Have you reviewed the [Splunk Guide](splunk-transaction-guide.md) and [Splunk Example](splunk-use.md)
2. Network Zone Problems, DMZ/Public Internet Proxy but CORE API issues: [DMZ Troubleshooting](stargate-customer-troubleshooting.md#dmz)
3. Self-Service Problems, guide and examples: [Self-Service Guide](stargate-self-service.md) and [Self-Service Resource Examples](stargate-self-service-resources.md)
4. Layer 7 Migration questions: [Layer7 Migration](layer7-stargate-migration.md) and [Layer7 Client Migration](layer7-client-migration.md) and [Layer7 API Provider Migration](layer7-provider-migration.md)

If so, then contacting us will not be necessary and our documentation proves to be worthwhile!

In the event the above does not adequately provide you with the knowledge you seek then proceed.

### Alternative secondary approach

In the event our first line of defense above was no help, Stargate offers these choices:

1. When minimal detail is necessary - [Flowdock Communication](contactUs.md#for-questions)
2. When a lot of detail is necessary - Preferred: [Github Support Ticket](https://github.optum.com/APIGateway/support/issues/new/choose), or [Email Distribution List](contactUs.md#email-distro-list) 

At the minimum please provide a proxy URL associated with the issue if relevant to a proxy, and any details surrounding the issue as well as research done prior to engaging us.

We try to avoid getting tied up in webex calls unless absolutely necessary so please try to follow the above avenues for support!
