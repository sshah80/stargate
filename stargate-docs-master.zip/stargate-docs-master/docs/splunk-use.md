
## Access
Do you have access to our [splunk index](links.md#splunk-dashboards) on phi splunk? You will need to request the AD group **SSMOSplunk_stargate_prod** to gain access to search our index

## General query
Then you can query your services like so pretty easily:

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* `

## Current Health
Breakdown of the current health by status codes last 24  hours:

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* | chart count by HTTPStatus`

![](assets/splunk/splunk-httpstatus.png)

So overall looking  @ about 97% healthy calls(a large % of those were just
[CORS](stargate-cors.md) preflight options calls though with 1,700 real proxy calls), a few **401s** are expired/invalid token were passed too.

## Specific error code
**504s** refer to timeouts to backend service in the allotted gateway timeout, they all hit that 9 second limit on response time

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* AND HTTPStatus=504`

![](assets/splunk/splunk-504.png)

Distribution of timeouts detected seemed pretty equal between our gateways so its not datacenter specific

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* AND HTTPStatus=504 | chart count by host`

![](assets/splunk/splunk-by-dc.png)

Service breakdown for 504s as well:

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* AND HTTPStatus=504| chart count by ServiceName`


## Backend Latency
To view the latency of your services, use the following query.

`index=cba_stargate URI=*myurl/resource/endpoint1* OR URI=*myurl/resource/endpoint2* | timechart p50(BackendLatency) p95(BackendLatency) p99(BackendLatency)`

![](assets/splunk/splunk-latency.png)
