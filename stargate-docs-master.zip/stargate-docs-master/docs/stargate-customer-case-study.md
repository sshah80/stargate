
## Case Study 1

A customer was migrating from Layer 7 to Stargate and shared the following analysis.  They saw on average a **_65% performance increase_** to their 90th percentile measurement.

![](assets/case-study-1-graph.png)
![](assets/case-study-1-table.png)
