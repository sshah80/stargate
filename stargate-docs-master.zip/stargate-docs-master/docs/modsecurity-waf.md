
## Stargate + ModSecurity
As part of our continuing mission to improve the security and functionality of Stargate, we’re pleased to introduce the next layer of application security for the platform; the ModSecurity + OWASP Web Application Firewall!
h[ttps://github.com/SpiderLabs/owasp-modsecurity-crs/tree/v3.2.0/rules](https://github.com/SpiderLabs/owasp-modsecurity-crs/tree/v3.2.0/rules)

## Is the WAF Blocking my Transaction?
From February 11, 2020 we will be conducting an evaluation of the WAF in the Stage environments. 

For most users, this will not significantly impact your Stargate experience. For some, you may experience blocked transactions as a result of new WAF rules.

If you suspect the WAF might be blocking your transactions, in splunk search with:
```sql
index=cba_stargate ErrorMsg="*ModSec*" URI="/path/of/my/api/proxy"
```
And expect to see a result with the `ErrorMsg` field set!
![waf](assets/ModsecWAFBlock.png)

If you do see blocking on your transactions, please reach out to the Stargate API Gateway team via our [Flowdock](https://www.flowdock.com/app/uhg/api-gateway-evaluation) to report the issue!
