
## Splunk Transactions

**Splunk URL**: [https://phi-splunk.optum.com/](https://phi-splunk.optum.com/)

**Secure Group**: SSMOSplunk_stargate_prod (This covers all non-prod and prod transaction lookups)

**Search Index**: index=cba_stargate

![OpenShiftFireWall3](assets/SplunkTx.png)

## Field Definitions

### BackendLatency
 A BackendLatency of -1 means Stargate failed to proxy to the API service. Either due to Authorization related errors (HTTP Status 401) or potentially Layer 4 errors (tcp connection reset, ssl handshake errors, upstream connection prematurely closed by upstream) and these show up as HTTPStatus 500 level errors. Under normal successful transactions this field represents the time it takes for Backend API service to respond to Stargate.

### CID
CID is the unique ID we send to consumers/api providers when proxying traffic, see: [Useful Rest Headers](externalclientguide.md#useful-rest-headers)

### ClientIP
ClientIP is generally the consuming applications IP for this API call, a few oddities due to our network can cause this value to be incorrect at rare times but generally is a good source point to start for network debuggging.

### Consumer
Consumer is the programatically authorized Stargate consumer for this service, not a field that would be populated when using external identity providers in flows such as OpenID connect with ping federate.

### GatewayHost
GatewayHost is the Stargate gateway the consuming application choose to transact against for their API call.

### HTTPMethod
HTTPMethod is the method the consuming application choose to invoke the API service, there is a known issue if the tx is a Layer 4 proxy failure the method defaults to GET(this issue will be resolved in a later iteration of Stargate).

### HTTPStatus
HTTPStatus is generally the response HTTP Status code returned from the API unless you see BackendLatency -1, meaning we did not reverse proxy. And the code was one selected by Stargate in the event of failure to proxy/rate-limiting.

### RequestSize
RequestSize is the size in bytes of the full request payload.

### ResponseSize
ResponseSize is the size in bytes of the full response payload.

### RoutingURL
RoutingURL is the full path backend URL we transacted against.

### ServiceName
ServiceName is the name of the proxy service recorded in Stargate.

### TotalLatency
TotalLatency is the sum of the BackendLatency and Stargate processing time.

### Tries
Tries represents how many tcp connections were attempted to call an API service(we default our gateway to try once), within the tries array you will find a specific IP Stargate attempted to proxy to.

### URI
URI is the path the consumer called within Stargate

## Units of Measure
Request/Response Sizes recorded are in bytes

Latency information is in milliseconds
