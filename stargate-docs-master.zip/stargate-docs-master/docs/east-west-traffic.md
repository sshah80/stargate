

## For API Traffic that does not need an API Gateway(no multi consumers, no public internet accessibility) we recommend a few security patterns:

### Disclaimer: We don't provide support for these implementations, (BYOE) - bring your own engineers.

### OpenID Connect with PingFederate:

OpenID connect provides a powerful integration for web application user interfaces that can't store secret information and
generally requires a user to login via browser. The current LDAPs supported for user session logins are:

1. Optum ID, Contact: <sivaprasad_thanneru@optum.com>
2. HealthSafe ID, Contact: <sivaprasad_thanneru@optum.com>
3. MS ID(Active Directory), Contact: <siva_reddy@optum.com>

In this flow the client(website) would redirect to ping federates login landing page, successfully login and recieve a
session token after successful login. Then this website would use ajax calls to an API service with the users active session. Then the API
service is responsible for validating the session tokens against the identity provider(PingFederate) to ensure the tokens are valid and issued
from ping federate. The API service would get information about the user from ping and process further business logic based on if that user
meets their defined criteria of access.

### PROGRAMATIC Security Patterns:

One pattern we like around server 2 server authentication is RS256 JWT. In this pattern you generate a public/private key and the API service will maintain the public key for validation of the client consumer, and the client consumer will embed expiration timestamps and and sort of information they want protected in their transaction(user information or other arbitrary data) they want untampered with at validation time. Then the client signs this JWT with their private key so no other actor could produce such a JWT. Best part about JWT is its widely adopted and has well developed libraries in just about every popular programming language, read more here:

[JWT IO](https://jwt.io/)

Less favorite programmatic pattern but still very secure would be Mutual SSL, this pattern will require you to maintain Optum Certs for both servers as well as rotate them on an annual basis per EIS standards, this can be tricky and cause downtime if not managed carefully and appropriately(You need to update all server truststores and public certs at the same time each renewal!). Each application server will maintain the other servers public cert in their truststore and rotate out their truststores every year upon certificate renewal, read more about Mutual SSL here:

[Mutual SSL](https://www.codeproject.com/Articles/326574/An-Introduction-to-Mutual-SSL-Authentication)
