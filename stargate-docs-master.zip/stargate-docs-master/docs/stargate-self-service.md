
Create and Manage Stargate namespaces(consumers/teams) and proxy resources

## What is a namespace and how does it relate to Stargate?

A namespace can be an API Consumer and API Provider. When you have a namespace, you are given credentials and the ability to be authorized to API's hosted on Stargate(at the consent of API Providers adding your namespace name to their "authorizedConsumer" list. When publishing proxies you will notice they appear nested within the namespace directories representing ownership.

## Prerequisites

You must have these values on hand before integrating with Stargate Self-Service, they will be needed for creation of your namespace.

1. Most importantly, to use [github enterprise](https://github.optum.com) you must have the secure group github_users.

2. namespace: An acronym for your namespace/team name. Examples: myuhc, upm, optumrx. This should be a value identifiable to yourself
and your colleagues within the company. This value must be all lowercase and period delimited(if you need spacing), Ex: my.namespace .

3. sloEmail: The service level owner in charge of a namespace. This person will receive an email of credentials for the new namespace created, ensure the slo is aware of this and stores these credentials in a secure manner for the rest of their members to use when necessary.

4. teamEmailDL: The distribution list that will be contacted for this namespace, either directly by Stargate at times, or by automated alerts in the event that API services the namespace owns are in a failed state(think HTTP 500 level errors). Instructions on how to make an email DL can be found [here.](https://helpdesk.uhg.com/at_your_service/sw/pages/create-a-new-distribution-list.aspx)

5. askId: Every namespace integrating with Stargate should have a form of ask id, as it is the company standard around documentaton of integrations within our company.
ASK ID Directory can be found here: [http://orbit-ssrs-prod-int.optum.com/ReportServer/Pages/ReportViewer.aspx?/Optum+ET/ASKReports/ASK+Application+List](http://orbit-ssrs-prod-int.optum.com/ReportServer/Pages/ReportViewer.aspx?/Optum+ET/ASKReports/ASK+Application+List)

6. adGroup: Every namespace integrating with Stargate needs an active directory group designated that will allow its members to edit and create resources within a namespace. Creation of ad groups can be done here: [Secure AD Group Creation](https://secure.uhc.com/GroupMaintenance/CreateWindowsGroup).  **NOTE** Creation of a group does not add you to the group.  You will need to raise a second request to add yourself to the new group.

Example:
![AdGroupCreationExample](assets/adGroupCreationExample.png)


## Instructions

1. Study the resources and valid actions(create/update/delete) here: [Self-Service Resources](stargate-self-service-resources.md)

2. Fork [Self-Service](https://github.optum.com/APIGateway/stargate-self-service) repo, look for the top right button in the UI that says "fork"

3. Make up to 10 Stargate namespaces or proxy resources in the /requests folder 1 json text blob per file. Feel free to name the files in any convention you like, request1.json, request2.json etc. . Something important to note is the newer API Taxonomy Standards we are adhearing to for proxy creation, see below for non-prod vs prod proxy url formats:

Nonprod Example:<br />
gateway-stage.optum.com/api/{env}/{domain}/{sub-domain}/{namespace}/{resource}/{version}

Prod Example:<br />
gateway.optum.com/api/{domain}/{sub-domain}/{namespace}/{resource}/{version}

We do have a [video](stargate-self-service.md#video) guide out to help customers see this process in action!

Do note subdomain and namespace and version (defaults to v1 if empty) are optional and not necessarily required, best to check with the Taxonomy team about what your API service falls under with regards to domain and subdomain - <api_certification_dl@optum.com> .

### Production Proxy Certification

Production API services in need of a proxy must be certified, to become certified you must have a merged OpenAPI spec in this repo:
[Taxonomy Certification Repo](https://github.optum.com/API-Certification/Taxonomy-Review/tree/master/submissions)
Its important that you include the metadata.certificationFileName in your stargate-proxy json. For example if your approved OpenAPI spec was:  https://github.optum.com/API-Certification/Taxonomy-Review/blob/master/examples/example-api-spec.yaml, then you would populate your Stargate proxy request json with certificationFileName: "example-api-spec.yaml". It is also important your production proxy url request to the gateway is contained within one of the urls present in the approved OpenAPI spec combinations of ```servers``` concatenated with one of the ```paths```. Meeting both those criteria will allow your production proxy to be ready for creation in self-service.

You can find all valid combinations of domains and subdomains that our self-service allows here in json format:

[Taxonomy-JSON](https://github.optum.com/raw/API-Certification/Taxonomy-Review/master/scripts/domain-taxonomy.json)
So be sure to incorporate such logic into your stargate proxy resources otherwise validation will fail and further pull request revisions on your part will be neccessary! You should be populating the metadata.proxyUrl.domain/.subdomain fields with the human readable name element in proxy JSON above and not the uri element. Example: domain: "provider" is correct, not domain: "pdr" .

4. When complete, on your forked repo click the "pull request" option under the green "clone or download" button on the right hand side of github. This will open up a window where you can give a title to why you need to create these resources. And then a box below to go into more detail about your request. When done you can click submit at the bottom of the page. This will cause your pull request to enter our queue and be processed. Stargate namespaces are processed automatically, as well as stage proxies as long as there are no problems in the request.

Current Limitation: When needing to change the gateway host your self-service proxy was created on, please delete the existing proxy via self-service PR and create the proxy on the correct gateway host in a later PR. Otherwise you will see a "no serviceId found" error on your PR if you try to update an existing proxy on a totally seperate gateway.

Need DMZ to CORE routing and facing a network issue? See here for how to open DNS and Firewall Rule requests so DMZ Stargate can talk to your CORE hosted API Service: [Stargate Troubleshooting](stargate-customer-troubleshooting.md)

## OpenID Connect proxy or special use case not supported by self-service currently?
Feel free to leverage support for uncommon use cases through open dialog github issue tracking: [Submit support help here](https://github.optum.com/APIGateway/support/issues/new/choose)

## Bring in existing Stargate OAuth or JWT protected proxies made before self-service into self-service?

### Option 1

1. Login to the appropriate [Konga Link](links.md#ui-to-view-proxy-services-and-enabled-consumers) for your existing proxies depending on the correct network zone and environment where the proxies are hosted.

2. Open the lefthand-nav "Routes" tab, and search for your existing Proxy URL path ```/my/api/path/here``` in top right magnifying glass.

3. Once you have located your route, determine if your existing proxies service name follow the naming convention of ```namespace.service_name```. Example: ```optumrx.benefitsapi.dev```. Current namespaces in Stargate can be found [here](https://github.optum.com/APIGateway/stargate-self-service), every folder is a namespace and takes ownership of proxies created within it. **If your proxy name fits modern standards, proceed to step 5**

4. Submit an [issue](https://github.optum.com/APIGateway/support/issues/new/choose) to rename your existing proxies to the new ```namespace.service_name``` format.

5. To load your existing API into self-service, create an ```action: create``` PR for your API in [Stargate Self-service](stargate-self-service-resources.md#create-stargate-proxy) . During this request, metadata.proxyUrl will not modify your existing proxy. Note spec.proxyUrl is a readonly field that will be populated during the creation processing.

6. After PR is merged, submit an ```action: update``` request to change your spec.proxyUrl to taxonomy standards, based on ```metadata.proxyUrl.*```. Note authorizedConsumers list will alter consumer access on this request! Then you are done.

### Option 2

Compared to the above, you can review your existing proxies and then when finding the service name is not self-service standard and the routes proxy url is not matching taxonomy standard, you can do an ```"action": "create"``` pull request with the newer details of that service. Stargate will make a brand new proxy and all the settings you desire. Lastly send Stargate the list of old Stargate proxy urls you would like deleted and removed from the gateway permanently as an [issue](https://github.optum.com/APIGateway/support/issues/new/choose), that will be all that's necessary.

## Video
If you would like to watch a video of the process, please visit [this](https://optum.video.uhc.com/media/15+API+Workshop-section4-part1/0_h0lgde9d) evod link
