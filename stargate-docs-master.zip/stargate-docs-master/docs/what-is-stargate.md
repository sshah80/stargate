
## Stargate Features

|Feature||
|----|----|
| Gateway Technology | [Kong](https://konghq.com/solutions/gateway/) (nginx) |
| Publish API Documentation | doc-plugin |
| API Configuration and Administration | [Self Service Github Workflow](https://stargate-docs.optum.com/stargate-self-service/) |
| Consumer Management | [Self Service Github Workflow](https://stargate-docs.optum.com/stargate-self-service/)
| API Security | [Security Patterns](https://stargate-docs.optum.com/stargate-security/) |
| Rate Limit | [via plugin](https://stargate-docs.optum.com/stargate-plugins/#rate-limiting) Default: 500TPS per Consumer|
| Request Size Limitations | 20MB Maximum |
| Response Size Limitations | 50MB Maximum |
| Default Connection Timeout | 2 seconds|
| Default Read Timeout | 9 seconds|
| Analytics and Usage Reporting | [Grafana](https://stargate-docs.optum.com/links/#grafana-api-dashboard-urls) |
| High Performance | [Results](https://stargate-docs.optum.com/stargate-comparison/) |
| Scalability | High Scalability (Container based - OpenShift Origin)|
| Availability | Multi-Datacenter with Automatic Failover |
| Alerts and Notification | Driven via Grafana |
| Transformation - Request/Response | [via plugin](https://stargate-docs.optum.com/stargate-plugins/#request-transformer) limited use|
| Production Date | Since Feb 2018 |
| API Explorer | [https://api-explorer.optum.com](https://api-explorer.optum.com) <sup>(Chrome only)</sup> |
| Tracing | Implemented with [OpenTracing and Jaeger](https://stargate-docs.optum.com/links/#jaeger-opentracing)
| Documentation |https://stargate-docs.optum.com |
| Pricing | No current chargeback |
| Certification | Uses [Optum API Certification](https://api-docs.optum.com) |
