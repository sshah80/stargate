
|Type|Env|SLA|
|---|---|---|
|Create new proxy | Non-prod | 1 day |
|Create new proxy | Prod | 1 day|
|Respond to incident | Non-prod | 12 hours |
|Respond P1/P2 incident | Prod | ASAP |
|Respond P3 incident | Prod | 1 hour |
