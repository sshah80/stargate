
## Long running transactions in a microservice world

As we move more into a network of microservices having long running transactions becomes a problem.  Each service has the potential to engage another service for data.  When measuring performance of a client request, the time the client experiences will be the sum of all synchronous services that are in the call chain.  So one very slow call in the chain will make the entire chain slow.  We want to prevent this by promoting fast performant microservices.

## Can I get an exception?

There are no exceptions for the nine second transaction timeout limit unless this is a [lift and shift](layer7-stargate-migration.md#lift-and-shift) API from layer7.  We need to be performant to our clients.  While we recognize that transactions could take longer than nine seconds, it is not necessary to burden the consumers of an API with waiting.  Below are options on how you can have long running transactions run in the background and meet the nine second timeout restriction.

## Options for refactoring your application

* Have one API call to start a transaction and to return the transaction ID.  Then have a polling mechanism that gets the status of this transaction.  Polling ends whenever the transaction is completed.
* Do retries on the client side.  Don’t show the timeout error and make sure that the API is idempotent so you can retry with the same data and not have a duplicate transaction.
* Don’t use Stargate.  Standup the networking and firewall rules needed and have them approved by EIS.
* Move to public cloud and use the public cloud’s gateway where you could control the timeouts
* Use a distributed messaging system like Kafka to asynchronously put messages onto a queue for processing and then another message when the transaction is completed.
* Create a façade application that will cache the request/response on behalf of the client and forward requests to the application for processing.  This could be used in conjunction with #1
