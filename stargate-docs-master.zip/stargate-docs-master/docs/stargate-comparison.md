
## Performance testing results

### Load Testing results

***Resources:***

***CPU: 6***<br />
***MEM: 12 Gib***<br />

![LoadTestLatency](assets/LoadTestLatency.png)

These results show a Stargate pod maintains great performance right up to the 2,500 TPS threshold where resource contentions hit a ceiling. With a ***p95 latency right under 100ms at full load, Stargate is production ready and ready to handle any traffic volume the enterprise can dish out.*** 


***Resources(4 Stargate instances, 2 per Data center):***

***CPU: 24***<br />
***MEM: 48 Gib***<br />

![LoadTestThreads](assets/LoadTestTpsThreads.png)

These results show ***our capacity is designed to withstand 10,000 TPS.*** This is ***4x*** more available capacity than the existing API Traffic running through API Gateway solutions at the company on a small fraction of the resources.

### Automated performance testing results
Our automated performance tests provide their output into [github](https://github.optum.com/APIGateway/stargate-loadtesting-results)
