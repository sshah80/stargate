
## DMZ
Stargate Gateway(all gateways missing "-core" in the domain) routing to a CORE network API service issues:

Did you recently create a Stargate proxy hosted on a gateway that lives in the DMZ and routes to an API located in the CORE
network zone and its "not working" every call you send when calling the proxy url even though you are using proper gateway credentials?

If you can invoke your API and get an application response(meaning no Layer4 connection failures) when hitting your API url directly, then likely these network problems are at play:

| Response Body From Stargate | Reason |
|----------|:------------:|
| {"message":"name resolution failed"} | The domain of your API service ex: myapidomain.optum.com is not resolvable from the DMZ. To remedy this you need to make a request to DNS team(see further below for details). |
| The upstream server is timing out | The firewall rules in play are preventing Stargate in the DMZ from connecting to your API in the core. You need to request firewall rule changes through Enterprise Service Catalog tool (see further below for details).  |


## DNS Requests

How to expose DNS records for CORE Network host to APP DMZ Network to support DMZ Stargate gateway routing:

They have outlined a change in process(as of Sept. 6th) discussed [here](https://hubconnect.uhg.com/docs/DOC-210596)

  We suggest filling out the [Infrastructure Engineering Engagement](https://servicecatalog.uhc.com/sc/catalog.product.aspx?product_id=infrastructureengineeringengagement) form on Enterprise Service Catalog with details like so:
   
    What would you like to do?: General
    Description: DNS Help to resolve Core FQDN resolvable on DMZ Nameservers
    Business Justification/Detailed Description:
    "
    These VIPs
  
    https://my-subdomain.domain.com/
  
    are only resolvable from CORE network zone. I need these VIP DNS resolvable from App Zone DMZ.
    "

Sample Ticket a customer already published to [Enterprise Service Catalog](https://servicecatalog.uhc.com/sc/checkout.summary.aspx?order_number=1518052)

## Firewall Rule Requests
Firewall rules are exceptions to general Firewall configurations which, within UHG Standards, can allow traffic to flow between hosts in otherwise separated network segments. The following section describes the process  of submitting a request for a Firewall rule which will allow Stargate environments in the DMZ to route traffic to a CORE hosted API. 

*This process is owned and managed by the Palo Alto team (<Firewall@ds.uhc.com>). Our documentation on the process is subject to change as their process evolves.*

1. Navigate to the [ESC - Security Infrastructure Management](https://servicecatalog.uhc.com/sc/catalog.product.aspx?product_id=security_infrastructure_management)
![OpenShiftFireWall1](assets/FWESC_1.png)

2. Request Details Section<br/>
**Who This Service Is For** - Me<br/>
**Description** - Stargate DMZ (Openshift) to CORE API over TLS443 <br/>
**Contractually Obligated for Request to be Worked in United States**  - No <br/>
**Which Line of Business is this request owned and supported by**- { LoB of your Application  }<br/>
**Request Type** - Physical Firewall<br/>
![OpenShiftFireWall2](assets/FWESC_2.png)


3. Physical Firewall Control Section<br/>
**Is this request for an active Acquired Entity being integrated?** - No <br/>
**Action Type** - Add/Change a Firewall Rule<br/>
**PEX Status** - Not Required<br/>
**Business Justification** - API Gateway in DMZ needs access to API's located in the Core. <br/>
**Add/Modify NAT?** - No<br/>
![OpenShiftFireWall3](assets/FWESC_3.png)<br/>

4. Firewall Rules Section<br/>
**Firewall Rule Upload Type** - Manual Entry<br/>
**Source Host** - OSE3_DMZ_NODE-app-prod <br/>
**Source Address** - OSE3_DMZ_NODE-app-prod <br/>
**Destination Host** - { Hostname for your API } <br/>
**Destination Address** - { IP for that Hostname } <br/>
![OpenShiftFireWall4](assets/FWESC_4.png)


5. Accept the EULA, and Select "Add to Cart"
![OpenShiftFireWall5](assets/FWESC_5.png)

5. From the Cart, choose "Submit Request"
![OpenShiftFireWall6](assets/FWESC_6.png)

**Important Notes for F5 Users:**
If the domain is an F5 load balancer, you will likely have 2 IPs representing where traffic can go in each data center for high availability. To tell, you will see a -ctc or -elr in the domain on nslookup success resolution. Try both datacenter domains (including the -ctc or -elr) in your nslookup command to get the other IP. Another option is to search your domain in navigator if its an F5 loadbalancer and grab the IPs there: [F5 Lookup Tool](https://tech.optum.com/dashboard/networking/lookup)

Example Lookup and IPs highligted in red box:

![OpenShiftFireWall4](assets/OpenShiftFireWall4.png)

### Validating Firewall/DNS Rules
In order to validate your firewall/DNS changes completely, it is necessary to test your requests to both Stargate datacenters.

This can be accomplished by calling your proxy against both LTMs, for whichever Stargate VIP you will be using, directly.

LTM hostnames can be derived from the VIP hostname by appending "-elr" or "-ctc" to the "gateway" subdomain portion of the hostname:

Example:
```
VIP https://gateway-stage-dmz.optum.com/api/stage/myapp

ELR-LTM https://gateway-stage-dmz-elr.optum.com/api/stage/myapp
CTC-LTM https://gateway-stage-dmz-ctc.optum.com/api/stage/myapp
```

Any issues may be investigated using a splunk query, specifying your `path` in the `URI` field

```
index=cba_stargate URI="/api/stage/myapp*"
```

**Seeing 50% successful calls and the other 50% failing with the timeout error?** Firstly check your application to ensure all datacenters the API service loadbalances to is up and functional. If confirmed it likely means you have a firewall rule opened for 1 IP in a single datacenter and did not open the firewall for the other IP in the other datacenter . A second firewall rule request will be needed in such a situation to fix the other destination IP.

## SoapUI handshake_failure exceptions when you try to connect to Stargate?

This is because SoapUI tool does not trust the Optum signed certs on our gateway.

Review these various links for potential fix ideas
1. [Override the default jre](https://siking.wordpress.com/2016/02/18/another-way-to-fix-sslhandshakeexception-in-soapui/)

In this fix, you simply ensure you have java installed elsewhere, you can download from the UHG App Store as well, and then you override the jre of soapUI by renaming their jre folder so it ignores its bundled java and opts to use one of yours that will likely already have the truststore with Optum's Root+Intermediaries present in the chain.

2. [Ensure you support TLS 1.2 proto](https://www.igorkromin.net/index.php/2017/08/10/how-to-fix-soapui-javaxnetsslsslhandshakeexception-calling-weblogic-122-web-services-on-java-8/)

Stargate supports TLS 1.2, and SOAPUI should as well as its one of the most a modern and secure TLS connection protocols. 

3. [Override the bundled jre cacerts file](https://stackoverflow.com/questions/35849555/soapui-handshake-failure-on-https-endpoint-service)

Cacerts file controls what SOAPUI trusts for certificate authorities when it us connecting to secure endpoints. Since Optum signed certs are internal to our company its important we have a truststore that knows Optum signed certificates are trustworthy.

Note the certs would be found in [artifactory](https://repo1.uhc.com/artifactory/webapp/#/artifacts/browse/tree/General/UHG-certificates/optum)  If you use the truststore found in that repo, note the password is `password`.  Otherwise, you can grab all the certs and add them to your existing cacerts truststore by running the following script.

```bash
#!/bin/sh

CERT_DIR=$1
for cacert in $(find $CERT_DIR -name "*" -maxdepth 1 -type f 2>/dev/null)
do
    echo $cacert
    caname=$(basename -- "$cacert")
    caname="${caname%.*}"
    $JAVA_HOME/bin/keytool -importcert -noprompt -cacerts -alias $caname -file $cacert -storepass 'changeit'
done
```
