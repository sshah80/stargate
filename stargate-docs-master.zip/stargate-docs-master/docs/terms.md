
## Stargate API Gateway Terms of Service

These terms are applicable to all customers who leverage the gateway.

### Proxy Authentication

All proxies fronting API services within the company must have a form of authentication. No open passthrough proxies will be allowed.

### Proxy Management

Only one logical proxy per API per network zone, no duplicate proxies between DMZ Stargate and Core Stargate gateway for the same API service.

Our standard gateway timeouts are 2 seconds for Connection Timeout, and 9 seconds for Read Timeout. API’s which require exceptions to these timeouts must be approved through API Certification with remediation plans. Non-prod proxies are eligible for non-standard timeouts via self-service, under the stipulation that the customer acknowledges production proxies require an approved exception.

All production proxy management actions, including those performed with [Self-Service](stargate-self-service.md), must comply with [Stargate Change Control Requirements](stargate-change-control.md).

Stargate will only protect internally hosted UHG APIs. Stargate will not protect any externally hosted public/private API.

### Authentication Management

Clients who generate OAuth2.0 bearer tokens **MUST** cache their token appropriately for the lifespan of its validity. Failure to comply will result in credentials being revoked until proper logic is implemented on the client side. This is a necessity to keep our OAuth2.0 service responsive as a shared service to all clients.

### Credential Management Expectations
It is the responsibility of the Stargate customer to protect any private keys, secrets or credentials issued to them by Stargate.

In the event any private key, secret or credential is **compromised** in any manner the Stargate team will take the following actions:
 - **Compromised Non-Production Credential:** Namespace owners will be notified, and afforded a grace period of **24 hours** in which to rotate their credentials via [Stargate Self-Service](https://stargate-docs.optum.com/docs/self-service-fields.html#stargate-namespace-metadata). If credentials have not been rotated within the grace period afforded, **Stargate admins will rotate the credentials**, and notify the namespace SLO of the new ones.
  - **Compromised Production Credential:** Namespace owners will be notified, and the [Security Incident Response](https://optum.service-now.com/itss2?id=sc_cat_item&sys_id=8d0ff700db9888d0c121fcd6f4961906) (SIR) will be notified without delay. Stargate and Namespace admins will manage compromised credential rotation according to SIR direction. 

### Support Expectations

* **We will:**
   * Help resolve defects with Self Service.
   * Respond to support requests in FlowDock or GitHub on a best-effort basis.
   * Respond appropriately to production impact through ServiceNow+TCC with 24/7 support.
   * Publish current performance numbers for Stargate.

* **We will not:**
  * Attend your Deployment meeting.
  * Provision proxies for you if self-service can do it.
  * Attend recurring status meetings for you.
  * Proactively monitor logs for you (we gave you tools with which to do that yourself).
  * Join initial performance testing sessions.

### Subject to Change

Stargate reserves the right to change or modify any of the terms contained here at any time and at Stargate's sole discretion.
