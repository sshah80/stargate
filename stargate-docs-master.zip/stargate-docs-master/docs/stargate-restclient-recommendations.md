
## REST Client Applications(In order of quality):

### POSTMAN (Recommended)

Dowload Link: [Postman](https://www.getpostman.com/downloads/) 

Built in auth patterns coupled to your API requests<br />
Request history<br />
Easy SSL validation enable/disable in settings menu<br />
Lightweight<br />

### INSOMNIA (Recommended)

Download Link: [Insomnia](https://insomnia.rest/download/)

Elegant Theme and intuitive<br />
Lightweight<br />

Stargate REST Client Templates can be found [here](assets/Stargate-RESTclientTemplates.json)

### SOAPUI (Discouraged)

Download: [UHGAppStore](http://appstore.uhc.com/AppInfo/AppVersionId/13993?BackToList=/AppList/AppList)

Load Testing Tool is nice<br />
SSL CACert management causes many grief, see here [SoapUI Troubleshooting](stargate-customer-troubleshooting.md#soapui-handshake_failure-exceptions-when-you-try-to-connect-to-stargate)<br />
