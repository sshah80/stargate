
## For questions
[Stargate Technical Support has a Flowdock](https://www.flowdock.com/app/uhg/api-gateway-evaluation)! Please direct all questions related to Stargate Integrations (no matter how app-specific) here, for the most responsive support.  Please refrain from directly calling out specific team members as this only works to make our team less efficient in providing you the quickest support.  You may however use the @@APISecGatewaysTeam tag to notify the entire team.

If you're not on Flowdock yet - it's time [https://hubconnect.uhg.com/thread/95689](https://hubconnect.uhg.com/thread/95689)

## Email Distro list
<Stargate_API_Gateway_DL@ds.uhc.com>

## Public Facing Email
<stargate@optum.com>

## Office Hours
Occurs every Wednesday from 9:30AM CST until 11:00AM CST. [View Series](https://optumtech.webex.com/optumtech/j.php?MTID=mf4b6a2872666c471e4df7ece1d451b2a)

## Support Tickets
Please open an issue in [Github](https://github.optum.com/APIGateway/support)

## Emergency Production Issues
**Initiate a WarRoom**:

 1. Engage the TCC by calling the [UHG Helpdesk](https://helpdesk.uhg.com/Pages/Contact-the-Help-Desk-By-Phone.aspx#)
 
 2. Press `2` to speak with Incident Management
 
 3. Describe the problem, and ask to page "Stargate API Gateway" for immediate assistance
 
