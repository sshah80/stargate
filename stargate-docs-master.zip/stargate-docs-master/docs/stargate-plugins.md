
A Plugin entity represents a plugin configuration that will be executed during the HTTP request/response lifecycle. This section describes the plugins currently available on Stargate platforms.

## Authentication Plugins

Section describes the plugins used to achieve AuthN at the Gateway layer.
### OAuth 2.0 Authentication
Add an OAuth 2.0 authentication layer with the Authorization Code Grant, Client Credentials, Implicit Grant or Resource Owner Password Credentials Grant flow.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/oauth2/)
### JWT Authentication
Verify requests containing HS256 or RS256 signed JSON Web Tokens (as specified in RFC 7519).

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/jwt/)

### Multi-IDP OIDC
This plugin is custom, developed by Stargate to support OIDC flows within Optum.

It is configurable to this schema:
```
return {
  no_consumer = true,
  fields = {
    idp_header = { type = "string", required = true },
    idps = { type = "string", required = true}
  }
}
```
`IDPS` is an open configuration field, allowing an array of objects of the following elements


| Parameter | Default  | Required | description |
| --- | --- | --- | --- |
| `name` || true | plugin name, has to be `oidc` |
| `config.client_id` || true | OIDC Client ID |
| `config.client_secret` || true | OIDC Client secret |
| `config.discovery` | https://.well-known/openid-configuration | false | OIDC Discovery Endpoint (`/.well-known/openid-configuration`) |
| `config.scope` | oidc | false| OAuth2 Token scope. To use OIDC it has to contains the `oidc` scope |
| `config.ssl_verify` | false | false | Enable SSL verification to OIDC Provider |
| `config.session_secret` | | false | Additional parameter, which is used to encrypt the session cookie. Needs to be random |
| `config.introspection_endpoint` | | false | Token introspection endpoint |
| `config.bearer_only` | no | false | Only introspect tokens without redirecting |
| `config.realm` | kong | false | Realm used in WWW-Authenticate response header |
| `config.logout_path` | /logout | false | Absolute path used to logout from the OIDC RP |


[Full Documentation is available on Github](https://github.optum.com/DataExternalization/kong-oidc-multi-idp)

## Security Plugins
This section describes additional plugins available on Stargate which perform security checks, but which do not accomplish AuthN

### ACL
Restrict access to a Service or a Route by whitelisting or blacklisting consumers using arbitrary ACL group names. This plugin requires an authentication plugin to have been already enabled on the Service or Route.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/acl/)

### CORS
Add Cross-origin resource sharing (CORS) to a Route by enabling this plugin.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/cors/)

### Stargate Upstream JWT
This plugin was developed by Stargate, and has since been made Open-Source. It's use is to create an inject an RS256 JWT into the request header `JWT` for validation by API Providers

[Full Documentation is available on Github](https://github.com/Optum/kong-upstream-jwt)


## Traffic Control Plugins

This section describes plugins used to control traffic through Stargate, including throttling, modifying and terminating requests.

### Rate Limiting
Rate limit how many HTTP requests a developer can make in a given period of seconds, minutes, hours, days, months or years.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/rate-limiting/)

### Request Size Limiting
Block incoming requests whose body is greater than a specific size in megabytes.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/request-size-limiting/)

### Response Size Limiting
This plugin was developed by Stargate, and has since been made Open-Source. It's use is to terminate responses with `Content-Length` header value larger than a specified config.

```
return {
  fields = {
    allowed_payload_size = { default = 128, type = "number" }
  }
}
```

Configs allow this plugin to be applied to individual `Consumers` or all `Consumers`; and accept the maximum response size (in `MB`) to allow.


[Full Documentation is available on Github](https://github.com/Optum/kong-response-size-limiting)

### Path-Based Routing
This plugin was developed by Stargate, and has since been made Open-Source. This plugin will enable informing the hostname which Kong will route to based on elements in the request URI path. It allows for the concactination of both Regex' performed on the request URI path, and constants to form the routing hostname. 

Example:

kong-path-based-routing-plugin 'host_fields' args: 
```
[
  "$/api/service/(%S+)/",
  "$api/service/.*/v(%d+).",
  "$api/service/.*/v*..(%d+)",
  "-apitest.com"
]
```
on a request URI of https://kong-gateway/api/service/myapp/v1.0
to route with path: "/api"
would route to host:
myapp10-apitest.com/service/myapp/v1.0

The host given in the Service will not be used if this plugin is applied.
[Full Documentation is available on Github](https://github.com/Optum/kong-path-based-routing)

### Spec Expose
This plugin was developed by Stargate, and has since been made Open-Source. This plugin will expose the specification of auth protected API services fronted by the Kong gateway.

[Full Documentation is available on Github](https://github.com/Optum/kong-spec-expose)

### Cluster Drain
This plugin was developed by Stargate, and has since been made Open-Source. Drain and divert your traffic without briging down the LTM and iterrupting existing traffic by a switch that allows failing your healthcheck to a datacenter.ay.

[Full Documentation is available on Github](https://github.com/Optum/kong-cluster-drain)


### Request Termination
This plugin terminates incoming requests with a specified status code and message. This allows to (temporarily) stop traffic on a Service or a Route, or even block a Consumer.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/request-termination/)

## Analytics, Monitoring & Logging Plugins

### Zipkin
Propagate Zipkin distributed tracing spans, and report spans to a Zipkin server.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/zipkin/)

### StatsD
Log metrics for a Service, Route to a StatsD server. It can also be used to log metrics on Collectd daemon by enabling its Statsd plugin.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/statsd/)

### Splunk Log

This plugin was developed by Stargate, and has since been made Open-Source. It is designed to log API transactions to Splunk using the Splunk HTTP collector.

Schema:
```
return {
  fields = {
    splunk_endpoint = { required = true,  default = "https://hec-splunk.company.com/services/collector", type="url"},
    method = { default = "POST", enum = { "POST", "PUT", "PATCH" } },
    content_type = { default = "application/json", enum = { "application/json" } },
    timeout = { default = 10000, type = "number" },
    keepalive = { default = 60000, type = "number" },
    splunk_access_token = { default = "aaaaaaaa-bbbb-cccc-dddd-ffffffffffff", type="string"},
    retry_count = { default = 5, type = "number" },
    queue_size = { default = 20, type = "number" },
    flush_timeout = { default = 30, type = "number" }
  }
}
```
The results are splunk logs in the following format:

![Splunk Image](https://github.com/Optum/kong-splunk-log/raw/master/SplunkLogSample.png)

[Full Documentation is available on Github](https://github.com/Optum/kong-splunk-log)


## Transformation Plugins
This section describes plugins which modify the HTTP Request or Response content.

### Request Transformer
Transform the request sent by a client on the fly on Kong, before hitting the upstream server.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/request-transformer/)

### Correlation ID
Injects request header `optum-cid-ext` with random UUID if not found in request, passes through if found.

[Docs for this plugin are available on KongHQ](https://docs.konghq.com/hub/kong-inc/correlation-id/)


