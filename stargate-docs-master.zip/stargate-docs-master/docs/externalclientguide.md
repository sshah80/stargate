

Stargate Gateway Environments: <br/>
https://gateway-stage[-dmz,-core].optum.com/* <br/>
https://gateway[-dmz,-core].optum.com/* <br/>

OAuth2.0 client credential bearer token endpoints(Preferred - New): <br/>
https://gateway-stage[-dmz,-core].optum.com/auth/oauth2/cached/token <br/>
https://gateway[-dmz,-core].optum.com/auth/oauth2/cached/token <br/>

JSON payload to POST to generate an OAuth2.0 bearer token based on your secret: <br/>
```js
{
 "client_id": "yourClientIdHere",
 "client_secret": "yourClientSecretHere",
 "grant_type": "client_credentials"
}
```

Response will come back like so:
```
{
   "token_type": "bearer",
   "access_token": "X9sy5Ev9JPT9BY53ECzadu375R0lIctu",
   "expires_in": XXXX
}
```

To apply your generated token send in REST Authorization header like so:
```
Authorization: Bearer yourTokenHere
```

Note, it is important the client application will cache the token for the duration of the ```expires_in``` response element
for reuse on multiple requests. ```expires_in``` is a numeric in seconds for how long the ```access_token`` in the response will be valid for use.

### Common StarGate Error Codes/Responses

| HTTP Status Code  | JSON Response Body  |  Cause  
|---|---|---
| 401  | {"error_description":"The access token is invalid or has expired","error":"invalid_token"}  | OAuth2.0 Bad/Expired token
| 403  | {"message":"You cannot consume this service"}  | Consumer not authorized to call proxy
| 404  | {"message":"no Route matched with those values"}  |  Proxy endpoint does not exist
| 429  | {"message":"API rate limit exceeded"}  | Consumer has hit the Rate Limit


### Useful REST Headers:

| Header                | Description                                                                                                                                                           | Sample Value                         |
|-----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------|
| `X-Consumer-ID`       | A UUID generated within Stargate, which is associated with the authenticated consumer.<br/>This value is the same for each consumer, across all gateways and environments. **ONLY PRESENT IN PROGRAMMATIC AUTH CALLS** | c0144a38-c309-4522-973c-dfb9d8c674cc |
| `X-Consumer-Username` | The human-readable name of the authenticated consumer  **ONLY PRESENT IN PROGRAMMATIC AUTH CALLS**                                                                                                     | stargate.test.consumer               |
| `optum-cid-ext` | unique correlation-id uuid#int | c164c7a7-db63-4b1e-9ee6-84ee6a075b95#117729 |
|`X-Upstream-Latency` | The upstream latency in milliseconds of the API call | 73 |
| `X-Proxy-Latency` | The latency in milliseconds of the gateway | 15 |



### Other Common HTTP Status codes you may encounter:
|HTTP Code| HTTP Code Name|
|---|---|
|200 |OK |
|201 |Created|
|204 |No Content |
|400 |Bad Request |
|401 |Unauthorized |
|403 |Forbidden |
|404 |Not Found |
|405 |Method Not Allowed |
|409 |Conflict |
|415 |Unsupported Media Type |
|500 |Internal Server Error |
|503 |Service Unavailable |
