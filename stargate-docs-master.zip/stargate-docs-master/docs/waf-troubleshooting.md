
## When is the WAF(Web Application Firewall) involved when calling Stargate?

Any consumer invoking the public internet facing VIPs of Stargate:

https://gateway-stage.optum.com

https://gateway.optum.com

## What can occur?

The WAF may block traffic from a client prior to reaching the Stargate application if the request triggers one of the predefined rulesets for traffic the WAF considers suspicious.

If the WAF is blocking a transaction, the response to the client consumer will be a webpage and it will have a support Id embedded as well.

![](assets/WAFBlock.png)

It is important the client capture this support Id shown above in browser view, in the raw HTTP Body you will see the message displays like so:

```
<p>The requested URL was rejected.</p>
        <p>You may call customer service and provide this number if you should see this 
message again:</p>
        <div id="supportId">XXXXXXXXXXXXXXXXXXXX</div>
```

The ```supportId``` is the value the client must reference when making a Service Now ticket.

## How to report the problem if WAF blocks my traffic like the above sample?

Customer will make a Service Now Incident ticket to ```ISO - CYBER DEFENSE SUPPORT``` group

In the ticket please specify two things:

Title: F5 ASM WAF Blocking Proxy Traffic to Stargate

1. Stargate full proxy url, Ex: https://gateway.optum.com/api/service/v1
2. The ```supportId``` associated to the blocked client transaction

With this information in hand, the ISO Cyber Defense team will likely reassign the ticket to ```ISO - F5 Application Security Module```

Once your ticket has been evaluated, the WAF team will confirm with you via email or INC ticket what they resolved the root cause of the problem to be and what can be done about it. Then expect them to request your team to make a webex to follow up and test changes to the WAF that will allow your transaction through to Stargate.

The actual F5 WAF team consists of a few folk:

- Manager: Chu, Benjamin A <benjamin_a_chu@optum.com>
- Engineer: Spillman, Eric <eric.spillman@optum.com>
- Engineer: Sawyer, Mathew M <mathew.sawyer@optum.com>

In the event this WAF change is for production. After root cause analysis is complete, along with the webex mentioned above the ASM team will
need to process these adjustments under a valid CHANGE ticket, you can assign the CHANGE TICKET to the ```Stargate API Gateway```
Service Now Group, and follow up with a CHANGE TASK within the CHANGE ticket assigned to the WAF Engineer they give the work to.

The F5 ASM team can provide what F5 Devices to impact as well as what to state in the description of the CHANGE TICKET + TASK.
