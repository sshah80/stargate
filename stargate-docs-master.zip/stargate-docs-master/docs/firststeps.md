
## Step 0 - Review our Terms of Service
Please review our [Terms of Service](terms.md).  

## Step 1 - Review Gateway Vips
Firstly See [this link](links.md) to see the different vips and what network zones they support:


![Gateway VIP Flows](assets/Stargate-Highlevel-Network.png)

Use the above diagram to determine the correct Stargate VIP for your services based on **API hosting location** and **Consuming App** location:

1. DMZ Shared (nonprod hostname `gateway-stage-dmz.optum.com`,
    public internet/presentation dmz facing `gateway-stage.optum.com`)
    Note: [Please see here for more details on exposure for public internet consumers](#enabling-api-consumption-from-public-internet)

2. CORE Shared (nonprod hostname `gateway-stage-core.optum.com`)

## Step 2 - Team Definition
Decide on a team name to represent yourself and fellow colleagues and developers with your group. We refer to this as Stargate “teams”, ex: UPM4, RALLY, MYUHC … If you have one already set up as well let us know. A team should have an SLO primary name/email contact and a team distribution email list for contact as well.

## Step 3 - Review Self Service steps
Review the steps found in the [self service guide](stargate-self-service.md).
## Step 4 - Namespace Definition
Create a [namespace](stargate-self-service-resources.md#stargate-namespace) within Stargate Self service.  

## Step 5 - Proxy Definition
Create a [proxy](stargate-self-service-resources.md#create-stargate-proxy) within Stargate Self Service.

## Step 6 - Nonprod Proxy Creation
Once you have completed Steps 1-4 the proxy should be created, and credentials issued.

## Step 7 - Provider-side JWT Validation
Make sure your backend Microservices are doing Stargate API Provider JWT validation logic:
[https://github.optum.com/DataExternalization/api-gateway/tree/dev/ApiProviderAssets/JWT](https://github.optum.com/DataExternalization/api-gateway/tree/dev/ApiProviderAssets/JWT)

## Step 8 - Get Certified
Before publishing a prod proxy you must go through API Certification, I also recommend reading best practices too for developing proper api services:

### Certification Process
[https://api-docs.optum.com/](https://api-docs.optum.com/)

### REST API Best Practices
[https://api-docs.optum.com/standards/introduction/](https://api-docs.optum.com/standards/introduction/)

## Technical Support
[Stargate Technical Support has a Flowdock](https://www.flowdock.com/app/uhg/api-gateway-evaluation)! Please direct all questions related to Stargate Integrations (no matter how app-specific) here, for the most responsive support.

If you're not on Flowdock yet - it's time [https://hubconnect.uhg.com/thread/95689](https://hubconnect.uhg.com/thread/95689)


## Enabling API Consumption from public internet

**You must publish the proxy to a DMZ gateway, and share a proxy URL using the external VIP with your public consumer. They will not be able to access our internal vip. External Vips: `gateway-stage.optum.com`, or `gateway.optum.com`.**
    
**Note: If the API Service is hosted in the CORE Network Zone fronted by its own personal F5, or the API routes directly to the host machine itself exposed on the public facing gateway, then it is neccessary to create Firewall and DNS requests for connectivity of Stargate to the API (the only exception are API Services directly exposed on OpenShift Routes, Stargate can communicate with those already) -**

[https://stargate-docs.optum.com/stargate-customer-troubleshooting/#firewall-rule-requests](https://stargate-docs.optum.com/stargate-customer-troubleshooting/#firewall-rule-requests) <br />
[https://stargate-docs.optum.com/stargate-customer-troubleshooting/#dns-requests](https://stargate-docs.optum.com/stargate-customer-troubleshooting/#dns-requests)
