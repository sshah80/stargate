![](assets/StargateLogo.png)
###[Get Started](firststeps.md)
Go here to get started working with Stargate API Gateway
###[Learn about Stargate](what-is-stargate.md)
This is where you can learn all about Stargate and all it supports
