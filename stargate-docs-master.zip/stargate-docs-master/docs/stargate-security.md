
There are two categories of client-side Security Pattern which Stargate supports, **Programmatic Auth**, and **User Auth**. A pattern falls under **Programmatic Auth** when the authenticated API consumer is an application, and **User Auth** when the authenticated API consumer is an individual user account. The decision of which type of auth to leverage should start with this determination.

For usecases requiring support for multiple authentication patterns, it will be necessary to create separate Stargate proxies for each auth pattern, as Stargate cannot optionally apply multiple auth patterns to the same proxy.

The **Provider-Side JWT** is a common pattern for provider-side authentication, which is applied to all Stargate proxies, regardless of client-side auth pattern. This is the **Stargate JWT**. The purpose of this security pattern is to allow the API to validate that incoming requests were proxied by Stargate. Without it, the client-side auth loses meaning, as any malicious actor could simply send traffic to the API's route directly, bypassing Stargate.


## Programmatic Auth Patterns

These are patterns where the authenticated API consumer is an application, not a person. These patterns are secure in implementations where the entire auth process is handled server-side, and none of the credentials or tokens are accessible to the end-user (either via Javascript, Cookies or otherwise).

In order to provide a means for the protected API to know which consuming application was authenticated at the Gateway for a given request, Stargate will encode the headers `X-Consumer-ID` and `X-Consumer-Username` into the request proxied to the protected API.

| Header                | Description                                                                                                                                                           | Sample Value                         |
|-----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------|
| `X-Consumer-ID`       | A UUID generated within Stargate, which is associated with the authenticated consumer.<br/>This value is the same for each consumer, across all gateways and environments | c0144a38-c309-4522-973c-dfb9d8c674cc |
| `X-Consumer-Username` | The human-readable name of the authenticated consumer                                                                                                                 | stargate.test.consumer               |

### HS256 JWT - Preferred
A JWT (json web token) is simply base64 encoded JSON, which has been signed. In this case, using the symmetric `HS256` HMAC algorithm.

Similar to OAuth Client Credentials, a HS256 JWT Consumer is issued a `key` and `secret` by Stargate, which are associated with an internal Stargate consumer resource. These credentials are used to generated a temporary JWT token, which is the means of authentication to the proxy.


Here are the steps a consumer must follow (after being issued credentials) to successfully make requests to an HS256 JWT protected services.
#### Step 1: Generate Temporary JWT Token
In this pattern, the consuming application generates the JWT locally, without contacting an external resource. A JWT is separated into 3 sections (`header`, `payload` and `signature`), and can be generated manually with unix commandline utils. However, the most common way to generate a JWT is to use one of [these libraries](https://jwt.io/) within the client code.

**IMPORTANT** - Because the client application generates the JWT itself, it also needs to set the token ttl in the `exp` claim within the `payload` section. The `exp` value is the unix timestamp when the JWT is set to expire, and although the client can technically encode any value in this claim, Stargate will reject any JWT with `exp` claim set to more than 1 hour into the future. This is to ensure tokens are rotated regularly, and security is more difficult to compromise.

The expected format of an HS256 JWT for Stargate auth is:


```javascript
// Header Section
{
  "alg":"HS256",
  "typ":"JWT"
}

// Payload Section
{
  "exp": current_unix_timestamp + 1 hour,
  "iss": "HS256 KEY issued by Stargate"
}

// Signature Section
hmacsha256(base64encode(header).base64encode(payload), "HS256 SECRET issued by Stargate")

---

// Putting it all together
JWT = base64encode(header).base64encode(payload).base64encode(signature)
```

Luckily, we don't need to manually format this token with bash and openssl, we have libraries to make life easy!

**Our HS256 Stargate Client Java library can be [found here](https://github.optum.com/APIGateway/stargate-client-auth)**

Sample HS256 JWT (copy/paste this into parser on https://jwt.io to see the sections)
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJteV9zdGFyZ2F0ZV9rZXkiLCJleHAiOjE1NTAyMDg5Mjl9.e4D1tLZ_v7AABBCcfw2aKNsSk3nfRPNZYoW8H5UPNrE
```

#### Step 2: Authenticated API Call with HS256 JWT
To pass the JWT to Stargate upon successful token generation, add a request header `Authorization: Bearer <jwt token>` to the proxy call.
```
REQUEST_METHOD https://[gateway hostname]/[path to the proxy]
Authorization: Bearer <jwt token>

...
```

#### Flow Diagram
![Stargate HS256 JWT](https://github.optum.com/APIGateway/stargate-docs/blob/master/docs/assets/Stargate%20HS256%20JWT.png?raw=true)

[Full HS256 JWT Spec](https://tools.ietf.org/html/rfc7519)

<hr/>

### OAuth 2.0 Client Credentials

The most popular auth pattern within Optum, an OAuth Client Credentials consumer is issued a `client_id` and `client_secret` by Stargate, which are associated with an internal Stargate consumer resource. These credentials are used to generated a temporary `access_token`, which is the means of authentication to the proxy.

Here are the steps a consumer must follow (after being issued credentials) to successfully make requests to OAuth Client Credentials protected services.

#### Step 1: Generate Temporary `access_token`
The token generation call is the first out of two steps to successfully authenticate to an OAuth Client Credentials protected API. The `access_token` issued on a successful request is valid for the `expires_in` time (seconds), and can be used multiple times within that window.

The proper process for handling this token upon generation is to **cache the access_token**, and use it for future requests until the token expires which is defined by the ```expires_in``` field of the token response json.

**Our OAuth 2.0 Client Credentials Stargate Client Java library can be [found here](https://github.optum.com/APIGateway/stargate-client-auth)**

##### Token Request
```
POST https://[gateway hostname]/auth/oauth2/cached/token (Preferred - New)
POST https://[gateway hostname]/auth/oauth2/token (Deprecated - Old)
Content-Type: application/json

{
  "client_id": "[Client ID issued by Stargate]",
  "client_secret": "[Client Secret issued by Stargate]",
  "grant_type": "client_credentials"
}

```

##### Successful Token Generation Response
```
HTTP 200
{
  "token_type": "bearer",
  "access_token": "****",
  "expires_in": 1458
}
```

#### Step 2: Authenticated API Call with `access_token`
To pass the `access_token` to Stargate upon successful token generation, add a request header `Authorization: Bearer <access_token>` to the proxy call.
```
REQUEST_METHOD https://[gateway hostname]/[path to the proxy]
Authorization: Bearer <access_token>

...
```

#### Flow Diagram
![Stargate OAuth Client Credentials](https://github.optum.com/APIGateway/stargate-docs/blob/master/docs/assets/Stargate%20OAuth%202.0%20Client%20Credentials%20.png?raw=true)

[Full OAuth 2.0 Client Credentials Spec](https://tools.ietf.org/html/rfc6749#section-1.3.4)

---

### [Pilot] Mutual Authentication (MutualTLS)

At long last, Stargate has released support Mutual Authentication (MutualTLS/SSL)!

During this pilot phase, only **Non Producttion** integrations will be allowed. A full production release is expected before 5/1/2020.

Like all Programmatic Auth Patterns, Stargate must be the identity provider in MutualAuth flows. This means that **Stargate issues the Certificate/Keys used by Consumers to authenticate to Stargate**.

This is accomplsihed by means of a Certificate Management API exposed by Stargate.

#### Step 0: Pilot Onboarding
Due to the fact that this pattern is currently in buildout, we'd like all providers interested in adopting Mutual Authentication for their proxies to schedule a meeting with us to plan the integration.

Please send a meeting invite to: [Stargate_API_Gateway_DL@ds.uhc.com](mailto:Stargate_API_Gateway_DL@ds.uhc.com?Subject=Stargate%20MTLS%20Pilot...)
with subject: `Stargate MTLS Pilot...` 
to kick off your integration.

#### Step 1: Configure Mutual Authentication on Proxies
In Stargate Self-Service, use the `spec.auth` field `{"type": "mtls"}` to enable Mutual Authentication on a proxy.


#### Step 2: Generate Client Certificate/Key 
As stated above, consumers of MutualAuth proxies must obtain a Certificate/Key from Stargate. These are not issued by default on `namespace` creation, as other forms of credentials are.

Instead, these resources can be created by Consumers using the [Stargate Certificate Management API](https://api-explorer.optum.com/api-detail/5e85e86fca5fc60001e105f9).


#### Step 3: Enable MutualAuth on the Client
Most HTTP Clients, in most languages, will have some way to set a Certificate and Key for use in Auth during the handshake of an SSL request. This section will not, and cannot possibly go into detail on how to do that with possible consumption senarios.

However, in addition to the SSL configuration, **it is also nessessary for the client to use Port `8443` when calling the Stargate vips.**

Example: `https://gateway.optum.com:8443/path/of/some/proxy`

Stargate's port `443` does not listen for MutualAuth requests.

## User Auth Patterns
These are patterns in which the authenticated API consumer is an individual LDAP user. User Auth patterns are optimized for cases where server-side auth is not possible (SPAs), or improper for the usecase. They differ from programmatic auth in a few ways; but chief among them is that Stargate will allow any authenticated user to call the protected proxy. **It is the responsibility of the API to perform any post-gateway fine grain auth, based on the specific user's roles.**

Within Stargate, all patterns of User Auth use OIDC with Pingfederate as the identity provider. This means in order to perform a User Auth pattern, the client site must integrate with Pingfederate to handle logins.

**Currently, Pingfederate supports these LDAPS: `MSID (AD)`, `OptumID`, `HSID`.**


In order to provide a means for the protected API to know which user was authenticated at the Gateway for a given request, Stargate will encode the header `X-Userinfo` into the request proxied to the protected API. The contents of `X-Userinfo` is generated by Pingfederate, and the format will differ depending on the specific LDAP (`MSID`, `OptumID`, `HSID`) validating your token.

| Header                | Description                                     | Sample Value                         |
|-----------------------|---------------------------------------------------|--------------------------------------|
| `X-Userinfo`       | Validation results Stargate retrieved from Pingfederate upon successful auth| [see below]|

```json
// MSID Sample
{"email":"","supervisorId":"","family_name":"","id":"","first_name":"","name":"","phone_number":"","manager":"","department":"","company":"","employeeId":"","roles":["",""],"sub":"","middle_name":"","given_name":""}
```
<hr/>

### OIDC Introspection
| Pingfederate Supported LDAPS | Intake
|-----------------|-----|
|OptumID|[https://hubconnect.uhg.com/docs/DOC-186445](https://hubconnect.uhg.com/docs/DOC-186445|
|HSID|[https://hubconnect.uhg.com/docs/DOC-186445](https://hubconnect.uhg.com/docs/DOC-186445|
|MSID (AD)|[ServiceNow Ticket](https://optum.service-now.com/itss2/?id=sc_cat_item_guide&sys_id=713f59ecdb43b308ea7169c3ca961920&sysparm_category=d54ca5541b24ffc0c04c0d076e4bcb02) - Select `Web Access Management (WAM)`|

OIDC Introspection is best used in the case where the client app is capable of storing secure info, without the client having access. This flow is extremely similar to OIDC Auth Code, the only major difference is that the client generates an `access_token` against Pingfederate directly, without proxying the request through Stargate.

In this flow, the client application must be issued a `client_id` and `client_secret` for the pingfederate environment they will be using as an IDP. These credentials are used to generate an `access_token` with pingfederate upon successful user login.

#### Step 1: User Login
When the user first navigates to the client website, the website must `redirect` this user to a pingfederate site where they will be prompted for their LDAP credentials. Upon successfully logging in, pingfederate will redirect the user back to the client website (using a pre-configured redirect url), and include the `auth_code` query param.

This `auth_code` is a temporary code which allows us to generate an `access_token`, the means of authentication to Stargate.

#### Step 2: Generating the `access_token`
Once we have the code, we POST to generate our `access_token` to pingfederate. This request contains the `auth_code`, `client_id` and `client_secret`.

Please review pingfederate docs for the exact syntax of this request.

The response will contain our `access_token`, and a `refresh_token`.

#### Step 3: Authenticated API Call
Once we have our `access_token`, we can successfully call the OIDC protected proxy!
```
REQUEST_METHOD https://[gateway hostname]/[path to the proxy]
Authorization: Bearer <access_token>

...
```
#### Step 4: Refresh Token
Once we have used our `access_token` for the given TTL, we need to generate a new one. Our old `auth_code` isn't going to be helpful here, as pingfederate does not allow more than one token to be generated for an `auth_code`. So to avoid logging the user in again (to generate a new code), we use the `refresh_token` from Step 2 to generate a new `access_token`.

Please review pingfederate docs for the exact syntax of this request.

#### Flow Diagram
![Stargate HS256 JWT](https://github.optum.com/APIGateway/stargate-docs/blob/master/docs/assets/Stargate%20OIDC%20Introspection.png?raw=true)

[Full OIDC Spec](https://openid.net/developers/specs/)
<hr/>

## Provider-Side Stargate JWT
Regardless of the client-side Security Pattern in use for a given proxy, Stargate will always apply the Stargate JWT provider side security to every request. The purpose of this security pattern is to allow the API to validate that incoming requests were proxied by Stargate. Without it, the client-side auth loses meaning, as any malicious actor could simply send traffic to the API's route directly, bypassing Stargate.

For every incoming transaction, the API is responsible for validating the Stargate JWT before executing any business logic. If the JWT is missing or invalid, the API must respond with `HTTP 401 Unauthorized` - the exact contents of the payload are at your discretion.

The Stargate JWT is an RS256 Asymmetric token, singed with Stargate's private key. Included in the token itself in the header claim `x5c`, is der-encoded the public key used to validate it. The API must validate the certificate chain on this der-encoded cert before validating the token's signature.

The structure is

**Header:**
```json
{
  "x5c": ["...der-encoded cert data..."],
  "alg": "RS256",
  "typ": "JWT"
}
```

**Current Payload:**

```json
{
  "aud": "service-name", // The name of the backend service Stargate is proxying to
  "iss": "issuer", // Stargate
  "iat": 1550258274, // When JWT token was issued
  "exp": 1550258334, // 1 minute exp time
  "jti": "d4f10edb-c4f0-47d3-b7e0-90a30a885a0b", // Unique to every request - UUID
  "consumername": "consumer-username", // Stargate Consumer Username
  "consumerid": "consumer-id", // Stargate Consumer ID
  "payloadhash": "...sha256 hash of request payload..."
}
```

It is highly recommended to use one of our [**AVAILABLE LIBRARIES**](stargate-libraries.md) to perform this validation.

Note there are two Content-Type header values where api services will need to ignore the ```payloadhash``` element within the JWT. This is due to form data types not persisting order between Stargate and api services as they read in the http body, so Stargate produces a sha256() hash different from the api service. API services should still validate other aspects of the JWT token even under these unique edge case transaction types.

The Content-Type values to ignore the payloadhash validation claim within the JWT are as follows:

```
multipart/form-data
application/x-www-form-urlencoded
```

Using the Java library referenced above, to disable the payloadhash claim validation you can add an extra boolean parameter set to true on the validate() method.

```
// Test without payload validation
(new StargateJWTValidator()).validate(jwt, payload, ks, true);
```

### Sample JWT ECHO Server Responses

Use the two links below to inspect what Stargate sends as a JWT Header for testing purposes:

|ENV|URL|
|---|---|
|STAGE CORE| https://gateway-stage-core.optum.com/jwt/validation|
|STAGE DMZ| https://gateway-stage-dmz.optum.com/jwt/validation|

#### Flow Diagram
![Stargate HS256 JWT](https://github.optum.com/APIGateway/stargate-docs/blob/master/docs/assets/Stargate%20Provider%20Side%20JWT.png?raw=true)


## Provider-Side MutualTLS
Provider-Side MTLS (Mutual SSL) is an alternate pattern to Provider-Side JWT, which provides Authn on the `Gateway` -> `API Provider` hop. As with Provider-Side JWT, the purpose of this security pattern is to provide the Upstream API with a means to validate that incoming requests were proxied by Stargate. Without it, the client-side auth pattern loses effectiveness, as any malicious actor could send traffic to the API's route directly, bypassing Stargate.

Provider-Side MTLS is disabled by default on all Stargate proxies and can be optionally enabled via a boolean field in your [Stargate Proxy Resource Definition](stargate-self-service-fields.md#stargate-proxy-spec).

In this MutualTLS interaction, Stargate is the `client` and the Upstream API is the `server`.

One-way or "regular" TLS (HTTPS) will allow the `client` to validate the identity of the `server` via it's x509 Certificate. MutualTLS will allow both the `client` to validate the identity of the `server`, and the `server` to validate the identity of the `client` via each of their x509 Certificates respectively.

In order to accomplish this, the `server` will need to trust our client certificate, and be expecting to complete the MutualTLS handshake with the `client`. **In order for this pattern to be effective, ths server must reject all connection requests to the protected resources which are unable to complete the MutualSSL handshake**. 

Stargate's Public x509 Certificates are all Optum-signed, and each environment's public certificate is available for [Download on Artifactory](https://repo1.uhc.com/artifactory/webapp/#/artifacts/browse/tree/General/generic-local/com/optum/stargate/certs).

Stargate's annual certificate rotation period occurs in **August** each year. There will be a period of 14 days provided between our certificate renewal, and cert rotation in the running Gateway applications. Notification to all Stargate Namespaces will be sent in advance of each action.
